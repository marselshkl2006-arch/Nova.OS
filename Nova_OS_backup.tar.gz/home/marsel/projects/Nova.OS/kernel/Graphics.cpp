// kernel/graphics.cpp

#include <stdint.h>

namespace Graphics {
    void set_mode(int width, int height, int bpp);
    void draw_pixel(int x, int y, uint32_t color);
    void draw_rect(int x, int y, int w, int h, uint32_t color);
}