// kernel/adaptive_ui.h
#pragma once
#include "hal.h"

namespace AdaptiveUI {
    // Режимы интерфейса в зависимости от устройства
    enum class UIMode {
        DESKTOP_MODE,    // Оконный интерфейс
        PHONE_MODE,      // Навигация жестами
        TABLET_MODE,     // Гибридный интерфейс  
        CONSOLE_MODE,    // Только терминал
        EMBEDDED_MODE    // Минимальный интерфейс
    };
    
    struct DisplayMetrics {
        uint32_t width;
        uint32_t height;
        uint32_t dpi;
        bool touch_screen;
        bool keyboard_attached;
    };
    
    void initialize();
    UIMode detect_ui_mode();
    void apply_ui_mode(UIMode mode);
    
    // Адаптивные компоненты
    class AdaptiveWindow {
    private:
        DisplayMetrics metrics;
        
    public:
        void create(const char* title, uint32_t width, uint32_t height);
        void set_position(int x, int y);
        void draw();
        
        // Автоматическая адаптация под размер экрана
        void auto_adjust_layout();
    };
    
    // Универсальная система ввода
    class UniversalInput {
    public:
        enum InputType {
            TOUCH,
            MOUSE,
            KEYBOARD,
            GAMEPAD,
            GESTURE
        };
        
        struct InputEvent {
            InputType type;
            int x, y;
            int pressure; // Для touch
            int key_code; // Для keyboard
        };
        
        void process_input(InputEvent event);
    };
}