// kernel/android_runtime.h
#pragma once
#include <stdint.h>
#include <stddef.h>

namespace AndroidRuntime {
    // Поддержка Android компонентов
    enum AndroidComponent {
        ACTIVITY,
        SERVICE,
        BROADCAST_RECEIVER,
        CONTENT_PROVIDER
    };
    
    struct APKManifest {
        char package_name[128];
        char main_activity[128];
        int min_sdk_version;
        int target_sdk_version;
        uint32_t permissions;
    };
    
    // Инициализация Android среды
    void initialize();
    
    // Загрузка и запуск APK
    bool load_apk(const char* apk_path);
    void launch_activity(const char* activity_name);
    
    // JVM байткод → нативный код
    void* compile_dalvik_to_native(const uint8_t* dex_code, size_t dex_size);
    
    // Android системные сервисы
    void start_android_services();
}