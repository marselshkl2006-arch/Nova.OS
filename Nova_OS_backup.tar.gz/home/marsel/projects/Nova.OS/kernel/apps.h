// kernel/apps.h
namespace Apps {
    void init_system_apps();
    void launch_file_manager();
    void launch_text_editor();
    void launch_web_browser();
}