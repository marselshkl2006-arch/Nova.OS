// kernel/arch/x86/hal_x86.cpp - 32-bit version
#include <stdint.h>

namespace HAL {
    // x86-specific implementations
    void x86_initialize() {
        // x86 initialization
    }
    
    void x86_shutdown() {
        // QEMU shutdown
        asm volatile ("outw %w0, %1" : : "a"((uint16_t)0x2000), "d"((uint16_t)0x604));
    }
    
    void x86_reboot() {
        // Simple reboot
        asm volatile ("outb %0, %1" : : "a"((uint8_t)0xFE), "Nd"((uint16_t)0x64));
        asm volatile ("hlt");
    }
}