// kernel/ata.cpp
#include "ata.h"
#include "console.h"
#include <stdint.h>

#define ATA_PRIMARY_BASE 0x1F0
#define ATA_PRIMARY_CTRL 0x3F6

// Объявляем функции портового ввода-вывода
extern "C" uint8_t inb(uint16_t port);
extern "C" void outb(uint16_t port, uint8_t value);

namespace ATA {
    void initialize() {
        Console::write("💾 ATA: Initializing controller...\n");
        Console::write("💾 ATA: Basic initialization complete\n");
    }
    
    bool read_sectors(uint32_t lba, uint8_t sector_count, void* buffer) {
        Console::write("💾 ATA: Read sectors LBA=");
        Console::write_number(lba);
        Console::write(" count=");
        Console::write_number(sector_count);
        Console::write("\n");
        (void)buffer; // Пока не используем
        return true;
    }
    
    bool write_sectors(uint32_t lba, uint8_t sector_count, const void* buffer) {
        Console::write("💾 ATA: Write sectors LBA=");
        Console::write_number(lba);
        Console::write(" count=");
        Console::write_number(sector_count);
        Console::write("\n");
        (void)buffer; // Пока не используем
        return true;
    }
    
    void identify_drive() {
        Console::write("💾 ATA: Drive identification\n");
    }
}

// Реализации портовых функций
extern "C" uint8_t inb(uint16_t port) {
    uint8_t result;
    asm volatile("inb %1, %0" : "=a"(result) : "Nd"(port));
    return result;
}

extern "C" void outb(uint16_t port, uint8_t value) {
    asm volatile("outb %0, %1" : : "a"(value), "Nd"(port));
}
