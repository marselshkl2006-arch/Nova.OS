#include "compatibility.h"
#include "console.h"

namespace Compatibility {
    void initialize() {
        Console::write("🔗 Compatibility layer initialized\n");
    }
    
    bool load_executable(const char* filename, BinaryFormat format) {
        const char* format_name = "";
        switch(format) {
            case ELF_LINUX: format_name = "ELF (Linux)"; break;
            case PE_WINDOWS: format_name = "PE (Windows)"; break;
            case MACH_OSX: format_name = "Mach-O (macOS)"; break;
            case NOVA_NATIVE: format_name = "NOVA Native"; break;
        }
        Console::write("📦 Loading ");
        Console::write(format_name);
        Console::write(" executable: ");
        Console::write(filename);
        Console::write("\n");
        return true;
    }
    
    void set_compatibility_layer(SyscallAPI api) {
        const char* name = "";
        switch(api) {
            case LINUX_API: name = "Linux"; break;
            case WINDOWS_API: name = "Windows"; break;
            case POSIX_API: name = "POSIX"; break;
        }
        Console::write("🔗 Compatibility: ");
        Console::write(name);
        Console::write(" API\n");
    }
}
