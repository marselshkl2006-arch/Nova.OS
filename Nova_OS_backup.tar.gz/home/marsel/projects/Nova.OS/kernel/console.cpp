// kernel/console.cpp
#include "console.h"
#include <stdint.h>

// Определяем size_t если не определен
#ifndef _SIZE_T
#define _SIZE_T
typedef unsigned int size_t;
#endif

namespace Console {
    static const size_t VGA_WIDTH = 80;
    static const size_t VGA_HEIGHT = 25;
    static uint16_t* const VGA_MEMORY = (uint16_t*) 0xB8000;

    static size_t terminal_row;
    static size_t terminal_column;
    static uint8_t terminal_color;
    static uint16_t* terminal_buffer;

    // Serial port functions
    uint8_t inb(uint16_t port) {
        uint8_t result;
        asm volatile ("inb %1, %0" : "=a"(result) : "Nd"(port));
        return result;
    }

    void outb(uint16_t port, uint8_t value) {
        asm volatile ("outb %0, %1" : : "a"(value), "Nd"(port));
    }

    void initialize_serial() {
        outb(0x3F8 + 1, 0x00); // Disable interrupts
        outb(0x3F8 + 3, 0x80); // Enable DLAB
        outb(0x3F8 + 0, 0x03); // Set baud rate (low)
        outb(0x3F8 + 1, 0x00); // Set baud rate (high)
        outb(0x3F8 + 3, 0x03); // 8 bits, no parity, 1 stop bit
        outb(0x3F8 + 2, 0xC7); // Enable FIFO
        outb(0x3F8 + 4, 0x0B); // Enable IRQs
    }

    void write_serial(const char* str) {
        for (size_t i = 0; str[i] != '\0'; i++) {
            while ((inb(0x3F8 + 5) & 0x20) == 0); // Wait for transmit empty
            outb(0x3F8, str[i]);
        }
    }

    void initialize() {
        // Initialize VGA
        terminal_row = 0;
        terminal_column = 0;
        terminal_color = 15 | (0 << 4); // White on black
        terminal_buffer = VGA_MEMORY;
        
        for (size_t y = 0; y < VGA_HEIGHT; y++) {
            for (size_t x = 0; x < VGA_WIDTH; x++) {
                const size_t index = y * VGA_WIDTH + x;
                terminal_buffer[index] = (uint16_t) ' ' | (uint16_t) terminal_color << 8;
            }
        }

        // Initialize serial port for -nographic mode
        initialize_serial();
        write_serial("Console: Initialized (VGA + Serial)\n");
    }

    void set_color(uint8_t color) {
        terminal_color = color;
    }

    void put_entry_at(char c, uint8_t color, size_t x, size_t y) {
        const size_t index = y * VGA_WIDTH + x;
        terminal_buffer[index] = (uint16_t) c | (uint16_t) color << 8;
    }

    void put_char(char c) {
        if (c == '\n') {
            terminal_column = 0;
            if (++terminal_row == VGA_HEIGHT) {
                terminal_row = 0;
            }
            return;
        }
        
        put_entry_at(c, terminal_color, terminal_column, terminal_row);
        if (++terminal_column == VGA_WIDTH) {
            terminal_column = 0;
            if (++terminal_row == VGA_HEIGHT) {
                terminal_row = 0;
            }
        }
    }

    void write(const char* str) {
        // Write to both VGA and Serial
        write_serial(str); // This will work in -nographic mode
        
        for (size_t i = 0; str[i] != '\0'; i++) {
            put_char(str[i]);
        }
    }

    void write_char(char c) {
        put_char(c);
        while ((inb(0x3F8 + 5) & 0x20) == 0);
        outb(0x3F8, c);
    }

    void write_number(uint32_t num) {
        if (num == 0) {
            write("0");
            return;
        }

        char buffer[32];
        char* ptr = buffer + 31;
        *ptr = '\0';
        
        while (num != 0) {
            *--ptr = '0' + (num % 10);
            num /= 10;
        }
        
        write(ptr);
    }

    void clear() {
        for (size_t y = 0; y < VGA_HEIGHT; y++) {
            for (size_t x = 0; x < VGA_WIDTH; x++) {
                const size_t index = y * VGA_WIDTH + x;
                terminal_buffer[index] = (uint16_t) ' ' | (uint16_t) terminal_color << 8;
            }
        }
        terminal_row = 0;
        terminal_column = 0;
    }
}