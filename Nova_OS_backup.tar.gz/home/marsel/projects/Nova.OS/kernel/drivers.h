// kernel/drivers.h
namespace Drivers {
    void initialize();
    bool detect_graphics_card();
    bool setup_audio();
    bool init_usb();
}