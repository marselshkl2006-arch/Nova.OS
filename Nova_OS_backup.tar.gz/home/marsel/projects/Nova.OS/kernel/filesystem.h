// kernel/filesystem.h
#ifndef FILESYSTEM_H
#define FILESYSTEM_H

#include <stdint.h>

namespace FileSystem {
    void initialize();
    bool create_file(const char* filename);
    bool read_file(const char* filename, char* buffer, uint32_t size);
    bool write_file(const char* filename, const char* data, uint32_t size);
    bool delete_file(const char* filename);
}

#endif