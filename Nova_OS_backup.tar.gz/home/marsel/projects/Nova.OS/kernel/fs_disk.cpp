// kernel/fs_disk.cpp
#include "fs_disk.h"
#include "ata.h"
#include "console.h"
#include "memory.h"
#include "string.h"

struct DiskFileEntry {
    char name[28];
    uint32_t size;
    uint32_t start_sector;
};

struct DiskSuperblock {
    char signature[8];
    uint32_t total_sectors;
    uint32_t used_sectors;
    uint32_t file_count;
    DiskFileEntry files[64];
};

static DiskSuperblock superblock;

namespace FSDisk {
    void initialize() {
        // Пытаемся прочитать superblock
        if (!ATA::read_sectors(0, 1, &superblock)) {
            Console::write("📁 Creating new filesystem...\n");
            format_disk();
        } else if (strncmp(superblock.signature, "NOVAFS01", 8) != 0) {
            Console::write("📁 Formatting disk with NOVAFS...\n");
            format_disk();
        } else {
            Console::write("📁 Mounted NOVAFS filesystem\n");
            Console::write("📊 Files: ");
            Console::write_number(superblock.file_count);
            Console::write(", Used: ");
            Console::write_number(superblock.used_sectors);
            Console::write(" sectors\n");
        }
    }
    
    bool format_disk() {
        // Инициализируем superblock
        strcpy(superblock.signature, "NOVAFS01");
        superblock.total_sectors = 10000; // ~5MB
        superblock.used_sectors = 1; // superblock занимает 1 сектор
        superblock.file_count = 0;
        
        // Записываем superblock (заглушка)
        Console::write("💾 Formatting disk...\n");
        return true;
    }
    
    bool file_exists(const char* filename) {
        for (uint32_t i = 0; i < superblock.file_count; i++) {
            if (strcmp(superblock.files[i].name, filename) == 0) {
                return true;
            }
        }
        return false;
    }
    
    bool read_file(const char* filename, void* buffer) {
        for (uint32_t i = 0; i < superblock.file_count; i++) {
            if (strcmp(superblock.files[i].name, filename) == 0) {
                DiskFileEntry* file = &superblock.files[i];
                uint32_t sectors_needed = (file->size + 511) / 512;
                return ATA::read_sectors(file->start_sector, sectors_needed, buffer);
            }
        }
        return false;
    }
    
    void list_files() {
        if (superblock.file_count == 0) {
            Console::write("No files on disk\n");
            return;
        }
        
        Console::write("Disk files:\n");
        for (uint32_t i = 0; i < superblock.file_count; i++) {
            Console::write("  ");
            Console::write(superblock.files[i].name);
            Console::write(" (");
            Console::write_number(superblock.files[i].size);
            Console::write(" bytes) - sector ");
            Console::write_number(superblock.files[i].start_sector);
            Console::write("\n");
        }
    }
}
