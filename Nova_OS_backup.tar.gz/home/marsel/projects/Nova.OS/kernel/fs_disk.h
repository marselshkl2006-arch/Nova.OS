// kernel/fs_disk.h
#pragma once
#include <stdint.h>

namespace FSDisk {
    void initialize();
    bool format_disk();
    bool file_exists(const char* filename);
    uint32_t get_file_size(const char* filename);
    bool read_file(const char* filename, void* buffer);
    bool write_file(const char* filename, const void* data, uint32_t size);
    void list_files();
}