#include "gaming.h"
#include "console.h"

namespace Gaming {
    void initialize() {
        Console::write("🎮 Gaming subsystem initialized\n");
    }
    
    bool set_graphics_mode(GraphicsAPI api, bool exclusive) {
        const char* api_name = "";
        switch(api) {
            case OPENGL: api_name = "OpenGL"; break;
            case VULKAN: api_name = "Vulkan"; break;
            case DIRECTX11: api_name = "DirectX 11"; break;
            case DIRECTX12: api_name = "DirectX 12"; break;
        }
        Console::write("🎮 Graphics: ");
        Console::write(api_name);
        Console::write(exclusive ? " (Exclusive)\n" : " (Windowed)\n");
        return true;
    }
    
    void optimize_for_game(const GameProfile& profile) {
        Console::write("🎮 Optimizing for: ");
        Console::write(profile.name);
        Console::write("\n");
    }
    
    void enable_game_mode() {
        Console::write("🎮 Game Mode: ENABLED\n");
    }
    
    void disable_game_mode() {
        Console::write("🎮 Game Mode: DISABLED\n");
    }
}
