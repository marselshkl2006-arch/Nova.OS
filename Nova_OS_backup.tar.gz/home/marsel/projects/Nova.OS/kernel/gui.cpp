// kernel/gui.cpp
#include "gui.h"
#include "console.h"

namespace GUI {
    static Theme current_theme = Theme::NOVA_MODERN;
    
    void initialize() {
        Console::write("🎨 NovaOS GUI system initialized\n");
    }
    
    void set_theme(Theme theme) {
        current_theme = theme;
        
        const char* theme_name = "";
        switch(theme) {
            case Theme::NOVA_MODERN: theme_name = "NovaOS Modern"; break;
            case Theme::NOVA_CLASSIC: theme_name = "NovaOS Classic"; break;
            case Theme::NOVA_DARK: theme_name = "NovaOS Dark"; break;
            case Theme::NOVA_LIGHT: theme_name = "NovaOS Light"; break;
            case Theme::CUSTOM: theme_name = "Custom"; break;
        }
        
        Console::write("🎨 NovaOS Theme: ");
        Console::write(theme_name);
        Console::write("\n");
    }
    
    Window* create_window(const char* title, int width, int height) {
        Console::write("🪟 NovaOS Window: \"");
        Console::write(title);
        Console::write("\" (");
        Console::write_number(width);
        Console::write("x");
        Console::write_number(height);
        Console::write(")\n");
        return nullptr;
    }
    
    void draw_window(Window* window) {
        // Заглушка
        (void)window;
    }
}
