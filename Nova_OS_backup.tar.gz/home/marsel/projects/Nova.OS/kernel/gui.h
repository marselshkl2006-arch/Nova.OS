// kernel/gui.h
#pragma once
#include <stdint.h>

namespace GUI {
    // Стили интерфейса NovaOS
    enum class Theme {
        NOVA_MODERN,    // Современный стиль NovaOS
        NOVA_CLASSIC,   // Классический стиль NovaOS  
        NOVA_DARK,      // Темная тема NovaOS
        NOVA_LIGHT,     // Светлая тема NovaOS
        CUSTOM          // Пользовательский
    };
    
    struct Window {
        int x, y, width, height;
        char title[64];
        bool visible;
        Theme theme;
    };
    
    void initialize();
    void set_theme(Theme theme);
    Window* create_window(const char* title, int width, int height);
    void draw_window(Window* window);
}
