// kernel/hal.cpp - 32-bit version
#include "hal.h"
#include "console.h"

namespace HAL {
    void initialize() {
        Console::write("HAL: Initializing Hardware Abstraction Layer\n");
    }
    
    void* allocate_physical_page() {
        // Simple page allocation stub
        static char page[4096];
        return (void*)page;
    }
    
    void free_physical_page(void* page) {
        // Stub implementation
        (void)page; // Mark as used to avoid warning
    }
    
    void register_interrupt_handler(uint8_t interrupt, void (*handler)()) {
        // Stub - should be implemented in arch-specific HAL
        (void)interrupt;
        (void)handler;
    }
    
    void initialize_timer(uint32_t frequency_hz) {
        // Stub - should set up PIT or APIC
        (void)frequency_hz;
    }
    
    void put_char(char c) {
        // Basic VGA output - convert char to string for Console::write
        char str[2] = {c, '\0'};
        Console::write(str);
    }
    
    const char* get_arch_name() {
        return "x86";
    }
    
    const char* get_device_name() {
        return "NovaOS Device";
    }
    
    void enable_interrupts() {
        asm volatile ("sti");
    }
    
    void disable_interrupts() {
        asm volatile ("cli");
    }
}