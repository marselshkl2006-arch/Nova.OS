// kernel/hal.h
#ifndef HAL_H
#define HAL_H

#include <stdint.h>

namespace HAL {
    void initialize();
    void* allocate_physical_page();
    void free_physical_page(void* page);
    void register_interrupt_handler(uint8_t interrupt, void (*handler)());
    void initialize_timer(uint32_t frequency_hz);
    void put_char(char c);
    const char* get_arch_name();
    const char* get_device_name();  // ДОБАВЛЯЕМ ЭТУ ФУНКЦИЮ
    void enable_interrupts();
    void disable_interrupts();
}

#endif