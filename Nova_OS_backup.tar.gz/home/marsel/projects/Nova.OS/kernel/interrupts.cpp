// kernel/interrupts.cpp
#include "interrupts.h"
#include "console.h"

namespace Interrupts {
    void initialize() {
        Console::write("Interrupts: Initializing interrupt system\n");
        // Простая заглушка вместо реальной инициализации IDT
    }
    
    void load_idt(uint64_t idt_ptr) {
        // Заглушка для загрузки IDT
        (void)idt_ptr; // Подавляем предупреждение
    }
    
    void enable_interrupts() {
        asm volatile("sti");
    }
    
    void disable_interrupts() {
        asm volatile("cli");
    }
    
    void register_handler(int interrupt, void (*handler)()) {
        Console::write("Interrupts: Registered handler for interrupt ");
        Console::write_number(interrupt);
        Console::write("\n");
        (void)handler; // Подавляем предупреждение
    }
    
    extern "C" void interrupt_handler() {
        // Простой обработчик прерываний
        Console::write("Interrupt received\n");
    }
}