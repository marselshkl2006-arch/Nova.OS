#ifndef INTERRUPTS_H
#define INTERRUPTS_H

#include <stdint.h>

namespace Interrupts {
    void initialize();
    void enable();
    void disable();
}

#endif
