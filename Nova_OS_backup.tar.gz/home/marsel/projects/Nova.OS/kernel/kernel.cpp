// kernel/kernel.cpp
#include <stdint.h>
#include "console.h"
#include "memory.h"
#include "process.h"
#include "interrupts.h"
#include "timer.h"
#include "keyboard.h"
#include "filesystem.h"
#include "syscalls.h"
#include "shell.h"
#include "paging.h"
#include "ata.h"
#include "fs_disk.h"
#include "microkernel.h"
#include "gui.h"
#include "gaming.h"
#include "compatibility.h"
#include "hal.h"

struct multiboot_info {
    uint32_t flags;
    uint32_t mem_lower;
    uint32_t mem_upper;
};

extern "C" {

void kmain() {
    // Initialize console with serial support
    Console::initialize();
    Console::write("🚀 NovaOS Hybrid v5.0 Booting...\n");
    Console::write("📡 Serial console activated\n");
    
    // Basic system initialization
    MemoryManager::initialize();
    Console::write("✅ Memory initialized\n");
    
    Paging::initialize();
    Console::write("✅ Paging initialized\n");
    
    Interrupts::initialize();
    Console::write("✅ Interrupts initialized\n");
    
    Timer::initialize(1000);
    Console::write("✅ Timer initialized\n");
    
    Keyboard::initialize();
    Console::write("✅ Keyboard initialized\n");
    
    // File systems
    FileSystem::initialize();
    Console::write("✅ FileSystem initialized\n");
    
    ATA::initialize();
    Console::write("✅ ATA initialized\n");
    
    FSDisk::initialize();
    Console::write("✅ FSDisk initialized\n");
    
    // System components
    MicroKernel::initialize();
    Console::write("✅ MicroKernel initialized\n");
    
    GUI::initialize();
    Console::write("✅ GUI initialized\n");
    
    Gaming::initialize();
    Console::write("✅ Gaming initialized\n");
    
    Compatibility::initialize();
    Console::write("✅ Compatibility initialized\n");
    
    GUI::set_theme(GUI::Theme::NOVA_MODERN);
    Console::write("✅ GUI theme set\n");
    
    Syscalls::initialize();
    Console::write("✅ Syscalls initialized\n");
    
    ProcessScheduler::initialize();
    Console::write("✅ ProcessScheduler initialized\n");
    
    Console::write("✨ Features: Universal Bootloader + NovaOS UI\n");
    
    // Enable paging
    Paging::enable();
    Console::write("✅ Paging enabled\n");
    
    // HAL initialization
    HAL::initialize();
    Console::write("🌍 Architecture: ");
    Console::write(HAL::get_arch_name());
    Console::write("\n");
    
    // Start shell
    Shell::initialize();
    Console::write("✅ Shell initialized\n");
    
    Console::write("🎉 NovaOS Ready! Serial output working!\n");
    Console::write("💡 Try commands: mem, device, arch, help\n");
    
    // Main kernel loop
    while(true) {
        asm volatile("hlt");
        ProcessScheduler::schedule();
        Shell::run();
    }
}

}