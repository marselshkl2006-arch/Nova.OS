// kernel/keyboard.cpp
#include "keyboard.h"
#include "console.h"

namespace Keyboard {
    static bool key_available = false;
    static char last_key = 0;
    
    void initialize() {
        Console::write("⌨ Keyboard initialized\n");
    }
    
    bool has_key() {
        // Простая заглушка - всегда возвращаем true для тестирования
        // В реальной системе здесь будет проверка порта клавиатуры
        return true;
    }
    
    char get_char() {
        // Заглушка для тестирования - возвращаем заранее заданные символы
        static const char* test_input = "mem\nhelp\narch\ndevice\nclear\n";
        static int index = 0;
        
        if (test_input[index] == '\0') {
            index = 0; // Зацикливаем ввод
        }
        
        return test_input[index++];
    }
    
    void handle_interrupt() {
        // Заглушка для обработчика прерываний клавиатуры
    }
}