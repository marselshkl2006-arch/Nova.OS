// kernel/libgcc_stubs.cpp - Заглушки для функций libgcc
#include <stdint.h>

extern "C" {
    // 64-битное деление
    uint64_t __udivdi3(uint64_t a, uint64_t b) {
        return a / b;
    }
    
    // 64-битное умножение
    uint64_t __umoddi3(uint64_t a, uint64_t b) {
        return a % b;
    }
    
    // 64-битное умножение
    int64_t __muldi3(int64_t a, int64_t b) {
        return a * b;
    }
    
    // Сравнение 64-битных чисел
    int __cmpdi2(int64_t a, int64_t b) {
        if (a < b) return -1;
        if (a > b) return 1;
        return 0;
    }
    
    // Сдвиг вправо
    int64_t __ashrdi3(int64_t a, int b) {
        return a >> b;
    }
    
    // Сдвиг влево
    int64_t __ashldi3(int64_t a, int b) {
        return a << b;
    }
    
    // Сдвиг вправо без знака
    uint64_t __lshrdi3(uint64_t a, int b) {
        return a >> b;
    }
}
