#include "compatibility.h"
#include "console.h"

namespace LinuxCompat {
    void initialize() {
        Console::write("🐧 Linux compatibility initialized\n");
    }
}
