// kernel/linux_compat.h
#pragma once
#include <stdint.h>
#include <stddef.h>

// Предварительное объявление, чтобы избежать циклических зависимостей
namespace FileSystem {
    struct File;
}

namespace LinuxCompat {
    // Linux системные вызовы
    void initialize();
    int open(const char* path, int flags);
    int read(int fd, void* buf, size_t count);
    int write(int fd, const void* buf, size_t count);
    int close(int fd);
    
    // /proc файловая система
    void mount_proc();
    const char* read_proc_file(const char* filename);
}