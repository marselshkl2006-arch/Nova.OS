#include "memory.h"
#include "console.h"

namespace MemoryManager {
    void initialize() {
        Console::write("MemoryManager: Initialized\n");
    }
    
    void* malloc(uint32_t size) {
        static char heap[8192];
        static uint32_t heap_ptr = 0;
        
        if (heap_ptr + size > sizeof(heap)) {
            return nullptr;
        }
        
        void* ptr = &heap[heap_ptr];
        heap_ptr += size;
        return ptr;
    }
    
    void free(void* ptr) {
        (void)ptr;
    }
    
    uint32_t get_total_memory() {
        return 16777216; // 16MB
    }
    
    uint32_t get_free_memory() {
        return 8388608; // 8MB
    }
    
    void* kmalloc(uint32_t size) {
        return malloc(size);
    }
    
    void kfree(void* ptr) {
        free(ptr);
    }
}
