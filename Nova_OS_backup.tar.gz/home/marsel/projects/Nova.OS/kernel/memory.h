// kernel/memory.h
#pragma once
#include <stdint.h>
#include <stddef.h>

namespace MemoryManager {
    struct MemoryBlock {
        size_t size;
        bool used;
        MemoryBlock* next;
    };
    
    void initialize();
    void* malloc(size_t size);
    void free(void* ptr);
    size_t get_free_memory();
    size_t get_total_memory();
    size_t get_used_memory();  // ДОБАВЛЯЕМ ЭТУ ФУНКЦИЮ
}

extern "C" {
    void* kmalloc(size_t size);
    void kfree(void* ptr);
}