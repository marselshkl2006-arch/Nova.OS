// kernel/memory_universal.h
#pragma once
#include <stdint.h>
#include "hal.h"
#include <stddef.h>

namespace UniversalMemory {
    struct MemoryMap {
        uint64_t base;
        uint64_t length;
        uint32_t type; // 1 = Available, 2 = Reserved, etc.
    };
    
    void initialize();
    void* malloc(size_t size);
    void free(void* ptr);
    
    // Универсальное выравнивание
    template<typename T>
    T* aligned_alloc(size_t alignment, size_t count) {
        return (T*)malloc(count * sizeof(T)); // В реальности с выравниванием
    }
    
    // Архитектурно-независимый аллокатор страниц
    void* allocate_page();
    void free_page(void* page);
    
    // DMA-совместимая память (для устройств)
    void* allocate_dma(size_t size);
}