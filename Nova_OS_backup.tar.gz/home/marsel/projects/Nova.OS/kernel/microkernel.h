// kernel/microkernel.h
#pragma once

#include <stdint.h>

namespace MicroKernel {
    // Базовые примитивы микроядра
    void initialize();
    
    // IPC (Inter-Process Communication)
    struct Message {
        uint32_t type;
        uint32_t from_pid;
        uint32_t to_pid;
        uint8_t data[256];
    };
    
    bool send_message(const Message& msg);
    bool receive_message(Message& msg);
    
    // Capability-based security
    struct Capability {
        uint32_t owner_pid;
        uint32_t permissions;
        void* resource;
    };
    
    bool check_capability(uint32_t pid, void* resource, uint32_t permission);
}