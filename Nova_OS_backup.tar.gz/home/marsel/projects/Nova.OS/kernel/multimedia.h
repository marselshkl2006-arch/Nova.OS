// kernel/multimedia.h
namespace Multimedia {
    void initialize();
    bool play_audio(const char* filename);
    bool display_image(const char* filename);
    void init_video_player();
}