// kernel/network.h

#include <stdint.h>
#include <stddef.h>

namespace Network {
    void initialize();
    bool send_packet(const void* data, size_t size);
    bool receive_packet(void* buffer, size_t size);
}