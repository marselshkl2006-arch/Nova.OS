// kernel/novaui_theme.cpp
#include "novaui_theme.h"
#include "console.h"
#include "gui.h"

namespace NovaUI {
    static bool dark_mode = false;
    static uint32_t accent_color = 0x0066FF; // Nova Blue
    
    void initialize() {
        Console::write("🎨 Initializing NovaUI theme system...\n");
        apply_theme();
    }
    
    void apply_theme() {
        Console::write("🎨 Applying NovaUI theme...\n");
        
        GUI::set_theme(GUI::Theme::NOVA_UI);
        
        if (dark_mode) {
            Console::write("   🌙 Dark mode enabled\n");
        } else {
            Console::write("   ☀️ Light mode enabled\n");
        }
        
        Console::write("   🎯 Accent color: Nova Blue\n");
        Console::write("   🔄 Smooth animations: Enabled\n");
        Console::write("   📱 Ergonomic navigation: Enabled\n");
    }
    
    void set_dark_mode(bool enable) {
        dark_mode = enable;
        apply_theme();
    }
}