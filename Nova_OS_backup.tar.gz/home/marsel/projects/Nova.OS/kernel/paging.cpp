// kernel/paging.cpp
#include "paging.h"
#include "console.h"

namespace Paging {
    void initialize() {
        Console::write("Paging: Initializing virtual memory\n");
    }
    
    void enable() {
        Console::write("Paging: Virtual memory enabled\n");
    }
    
    void* allocate_page() {
        static char page[4096];
        return (void*)page;
    }
    
    void free_page(void* page) {
        (void)page; // Подавляем предупреждение
    }
    
    void map_page(void* virtual_addr, void* physical_addr) {
        Console::write("Paging: Mapping page ");
        Console::write_number((uint32_t)virtual_addr);
        Console::write(" -> ");
        Console::write_number((uint32_t)physical_addr);
        Console::write("\n");
    }
}