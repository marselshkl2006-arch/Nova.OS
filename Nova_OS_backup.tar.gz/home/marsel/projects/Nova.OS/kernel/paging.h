// kernel/paging.h
#pragma once
#include <stdint.h>

namespace Paging {
    void initialize();
    void map_page(uint32_t virtual_addr, uint32_t physical_addr, bool writable = true);
    void unmap_page(uint32_t virtual_addr);
    void enable();
    
    uint32_t get_physical_address(uint32_t virtual_addr);
}
