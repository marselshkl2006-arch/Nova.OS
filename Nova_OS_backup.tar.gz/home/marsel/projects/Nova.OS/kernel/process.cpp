// kernel/process.cpp
#include "process.h"
#include "console.h"

// Заглушки для ProcessScheduler
namespace ProcessScheduler {
    void initialize() {
        Console::write("ProcessScheduler: Initialized\n");
    }
    
    void schedule() {
        // Простая заглушка
    }
    
    void* get_current_process() {
        return nullptr; // Заглушка
    }
}

// Заглушки для Process
namespace Process {
    void create(void (*entry)()) {
        Console::write("Process: Creating new process\n");
        (void)entry; // Подавляем предупреждение
    }
    
    void yield() {
        // Заглушка
    }
    
    int get_current_pid() {
        return 1; // Заглушка
    }
}