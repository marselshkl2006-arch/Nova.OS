#ifndef PROCESS_H
#define PROCESS_H

namespace ProcessScheduler {
    void initialize();
    void* create_process(const char* name, void (*entry_point)());
    void schedule();
    void* get_current_process();
    void exit_process(int pid);
}

#endif
