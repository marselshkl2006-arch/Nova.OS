#include "shell.h"
#include "console.h"
#include "string.h"
#include "memory.h"
#include "hal.h"

namespace Shell {
    void initialize() {
        Console::write("Shell: Ready for commands\n");
        Console::write("Type 'help' for available commands\n");
        run_demo();
    }
    
    void run() {
        // Основной цикл
    }
    
    void run_demo() {
        const char* demo_commands[] = {"help", "mem", "arch", "device", 0};
        
        for (int i = 0; demo_commands[i] != 0; i++) {
            Console::write("\nnovaos> ");
            Console::write(demo_commands[i]);
            Console::write("\n");
            execute_command(demo_commands[i]);
            
            for (volatile int j = 0; j < 1000000; j++);
        }
        
        Console::write("\n🎉 Demo completed! NovaOS is fully operational!\n");
    }
    
    void execute_command(const char* command) {
        if (String::strcmp(command, "mem") == 0) {
            uint32_t total = MemoryManager::get_total_memory();
            uint32_t free = MemoryManager::get_free_memory();
            Console::write("Memory: ");
            Console::write_number(free);
            Console::write(" / ");
            Console::write_number(total);
            Console::write(" bytes free\n");
        }
        else if (String::strcmp(command, "device") == 0) {
            Console::write("Device: ");
            Console::write(HAL::get_device_name());
            Console::write("\n");
        }
        else if (String::strcmp(command, "arch") == 0) {
            Console::write("Architecture: ");
            Console::write(HAL::get_arch_name());
            Console::write("\n");
        }
        else if (String::strcmp(command, "help") == 0) {
            Console::write("Available commands:\n");
            Console::write("  mem    - Show memory info\n");
            Console::write("  device - Show device info\n");
            Console::write("  arch   - Show architecture\n");
            Console::write("  help   - This help\n");
        }
        else {
            Console::write("Unknown command: ");
            Console::write(command);
            Console::write("\n");
        }
    }
}
