// kernel/shell.h
#ifndef SHELL_H
#define SHELL_H

namespace Shell {
    void initialize();
    void run();
    void execute_command(const char* command);
    void run_demo();
}

#endif