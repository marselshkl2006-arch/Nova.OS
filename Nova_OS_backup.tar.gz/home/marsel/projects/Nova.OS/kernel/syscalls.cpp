// kernel/syscalls.cpp
#include "syscalls.h"
#include "console.h"
#include "process.h"

// Заглушки для отсутствующих классов
class ProcessControlBlock {
public:
    int state;
};

namespace ProcessState {
    const int TERMINATED = 0;
}

namespace Syscalls {
    void initialize() {
        Console::write("Syscalls: System calls initialized\n");
    }
    
    void handle_syscall(uint32_t syscall_num, uint32_t arg1, uint32_t arg2, uint32_t arg3) {
        // Простая заглушка вместо реальной реализации
        Console::write("Syscall: ");
        Console::write_number(syscall_num);
        Console::write(" called\n");
        
        switch(syscall_num) {
            case 1: // write
                Console::write((const char*)arg1);
                break;
            case 2: // exit
                Console::write("Process exit requested\n");
                break;
            default:
                Console::write("Unknown syscall\n");
                break;
        }
        
        // Заглушка для ProcessScheduler
        Console::write("Syscall handled\n");
    }
    
    uint32_t sys_write(const char* str, uint32_t length) {
        Console::write(str);
        return length;
    }
    
    void sys_exit(int status) {
        Console::write("System exit called with status: ");
        Console::write_number(status);
        Console::write("\n");
        while(1) asm volatile("hlt");
    }
}