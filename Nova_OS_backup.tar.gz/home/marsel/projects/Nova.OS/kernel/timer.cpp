#include "timer.h"
#include "console.h"

namespace Timer {
    static uint64_t ticks = 0;

    extern "C" void timer_handler() {
        ticks++;
        if (ticks % 100 == 0) {
            Console::write(".");
        }
    }

    void initialize(uint32_t frequency) {
        Console::write("Timer: Initialized at ");
        Console::write_number(frequency);
        Console::write("Hz\n");
        
        // Note: Interrupts::register_handler is not available in simple version
        // Timer interrupts will be handled when full interrupt system is implemented
    }

    void wait(uint32_t ms) {
        // Simple delay - will be improved later
        volatile uint64_t end = ticks + ms;
        while (ticks < end) {
            asm volatile("pause");
        }
    }

    uint64_t get_ticks() {
        return ticks;
    }
}
