#ifndef TIMER_H
#define TIMER_H

#include <stdint.h>

namespace Timer {
    void initialize(uint32_t frequency);
    void wait(uint32_t ms);
    uint64_t get_ticks();
}

#endif
