// kernel/universal_binary.h
#pragma once
#include "hal.h"
#include <stddef.h>
#include <stdint.h>

namespace UniversalBinary {
    // Универсальный заголовок исполняемого файла
    struct FatBinaryHeader {
        char magic[8]; // "NOVAFAT"
        uint32_t version;
        uint32_t num_architectures;
    };
    
    struct ArchSection {
        Architecture arch;
        uint32_t offset;
        uint32_t size;
        uint32_t entry_point;
    };
    
    // Загрузчик универсальных бинарников
    bool load_fat_binary(const char* filename);
    void* get_arch_specific_code(Architecture arch);
    
    // JIT-компиляция для неподдерживаемых архитектур
    void* translate_binary(Architecture from, Architecture to, void* code, size_t size);
    
    // Универсальный системный ABI
    class UniversalABI {
    public:
        enum CallingConvention {
            SYSTEM_V,    // x86-64, ARM64
            WIN64,       // Windows x64
            AAPCS,       // ARM32
            X86_CDECL    // x86 32-bit
        };
        
        static CallingConvention get_calling_convention(Architecture arch);
    };
}