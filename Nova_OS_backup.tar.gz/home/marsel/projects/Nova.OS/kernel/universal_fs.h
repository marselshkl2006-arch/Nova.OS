// kernel/universal_fs.h
#pragma once

#include <stddef.h>
#include <stdint.h>

namespace UniversalFS {
    // Поддержка всех популярных ФС
    enum FilesystemType {
        NOVAFS,     // Нативная ФС Nova OS
        EXT4,       // Linux
        NTFS,       // Windows
        APFS,       // macOS
        FAT32,      // Универсальная
        F2FS,       // Flash-устройства
        EXFAT       // Современные SD карты
    };
    
    struct MountPoint {
        char path[64];
        FilesystemType fs_type;
        void* fs_data;
        bool read_only;
    };
    
    void initialize();
    bool mount(const char* path, FilesystemType fs_type, void* device);
    bool unmount(const char* path);
    
    // Универсальные операции с файлами
    class UniversalFile {
    public:
        virtual size_t read(void* buffer, size_t size) = 0;
        virtual size_t write(const void* buffer, size_t size) = 0;
        virtual bool seek(uint64_t position) = 0;
        virtual void close() = 0;
    };
    
    // Автоопределение ФС
    FilesystemType detect_filesystem(void* device);
}