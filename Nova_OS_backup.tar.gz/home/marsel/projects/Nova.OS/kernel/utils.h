// kernel/utils.h
namespace Utils {
    void system_info();
    void disk_usage();
    void process_monitor();
    void network_status();
}