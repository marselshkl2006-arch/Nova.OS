#include "compatibility.h"
#include "console.h"

namespace WindowsCompat {
    void initialize() {
        Console::write("🪟 Windows compatibility initialized\n");
    }
    
    void* MessageBoxA(void* hWnd, const char* text, const char* caption, unsigned int type) {
        Console::write("🪟 MessageBox: ");
        Console::write(caption);
        Console::write(" - ");
        Console::write(text);
        Console::write("\n");
        return nullptr;
    }
}
