// kernel/windows_compat.h
#pragma once
#include <stdint.h>

namespace WindowsCompat {
    // Win32 API
    void initialize();
    void* CreateWindowExA(uint32_t dwExStyle, const char* lpClassName, const char* lpWindowName,
                         uint32_t dwStyle, int x, int y, int nWidth, int nHeight,
                         void* hWndParent, void* hMenu, void* hInstance, void* lpParam);
    bool MessageBoxA(void* hWnd, const char* lpText, const char* lpCaption, uint32_t uType);
    
    // .NET поддержка
    void initialize_dotnet();
    void execute_assembly(const char* filename);
}