#!/bin/bash
echo "Запуск системы химической лаборатории..."
echo ""

# Проверяем зависимости
if ! command -v g++ &> /dev/null; then
    echo "Установите g++: sudo apt install g++"
    exit 1
fi

if ! command -v sqlite3 &> /dev/null; then
    echo "Установите sqlite3: sudo apt install sqlite3 libsqlite3-dev"
    exit 1
fi

# Создаем БД если нет
if [ ! -f "data/laboratory.db" ]; then
    echo "Создание базы данных..."
    make init_db
fi

# Компилируем
echo "Компиляция программы..."
make

# Запускаем
if [ -f "lab_system" ]; then
    echo ""
    echo "Запуск системы..."
    echo ""
    ./lab_system
else
    echo "Ошибка компиляции!"
fi
