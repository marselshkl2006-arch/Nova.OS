-- База данных химической лаборатории
-- SQLite версия

BEGIN TRANSACTION;

-- Химикаты
CREATE TABLE IF NOT EXISTS chemicals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    formula TEXT,
    type TEXT NOT NULL,
    danger_class INTEGER NOT NULL CHECK(danger_class >= 0 AND danger_class <= 5),
    storage_temp REAL NOT NULL,
    shelf_life_months INTEGER NOT NULL,
    quantity REAL DEFAULT 0,
    unit TEXT DEFAULT 'г',
    container TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Зоны хранения
CREATE TABLE IF NOT EXISTS storage_zones (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    temperature REAL NOT NULL,
    max_capacity REAL NOT NULL,
    current_load REAL DEFAULT 0,
    description TEXT
);

-- Партии
CREATE TABLE IF NOT EXISTS batches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chemical_id INTEGER NOT NULL,
    zone_id INTEGER,
    quantity REAL NOT NULL CHECK(quantity > 0),
    production_date TEXT NOT NULL,
    expiration_date TEXT NOT NULL,
    supplier TEXT,
    notes TEXT,
    FOREIGN KEY (chemical_id) REFERENCES chemicals(id) ON DELETE CASCADE,
    FOREIGN KEY (zone_id) REFERENCES storage_zones(id)
);

-- Пользователи
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    full_name TEXT,
    role TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Операции (лог)
CREATE TABLE IF NOT EXISTS operations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    action TEXT NOT NULL,
    details TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Индексы
CREATE INDEX IF NOT EXISTS idx_chemicals_name ON chemicals(name);
CREATE INDEX IF NOT EXISTS idx_batches_expiration ON batches(expiration_date);
CREATE INDEX IF NOT EXISTS idx_chemicals_type ON chemicals(type);

COMMIT;