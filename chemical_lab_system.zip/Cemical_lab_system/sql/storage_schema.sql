-- Зоны хранения с правилами совместимости
CREATE TABLE IF NOT EXISTS storage_zones (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    temperature REAL NOT NULL,
    humidity REAL,
    max_capacity REAL NOT NULL,
    current_load REAL DEFAULT 0,
    zone_type TEXT CHECK(zone_type IN ('refrigerator', 'freezer', 'room_temp', 'flammable', 'acid', 'base')),
    is_ventilated BOOLEAN DEFAULT 0,
    is_explosion_proof BOOLEAN DEFAULT 0,
    description TEXT
);

-- Какие классы опасности разрешены в зоне
CREATE TABLE IF NOT EXISTS zone_allowed_classes (
    zone_id INTEGER,
    danger_class INTEGER CHECK(danger_class BETWEEN 0 AND 5),
    FOREIGN KEY (zone_id) REFERENCES storage_zones(id) ON DELETE CASCADE,
    PRIMARY KEY (zone_id, danger_class)
);

-- Несовместимые типы химикатов в зоне
CREATE TABLE IF NOT EXISTS zone_incompatible_types (
    zone_id INTEGER,
    chemical_type TEXT,
    FOREIGN KEY (zone_id) REFERENCES storage_zones(id) ON DELETE CASCADE,
    PRIMARY KEY (zone_id, chemical_type)
);

-- Таблица размещений (какой химикат в какой зоне)
CREATE TABLE IF NOT EXISTS placements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    batch_id INTEGER NOT NULL,
    zone_id INTEGER NOT NULL,
    quantity REAL NOT NULL,
    placed_date DATE DEFAULT CURRENT_DATE,
    placed_by TEXT,
    notes TEXT,
    FOREIGN KEY (batch_id) REFERENCES batches(id) ON DELETE CASCADE,
    FOREIGN KEY (zone_id) REFERENCES storage_zones(id),
    UNIQUE(batch_id, zone_id)
);

-- Таблица истории перемещений
CREATE TABLE IF NOT EXISTS movement_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    batch_id INTEGER NOT NULL,
    from_zone_id INTEGER,
    to_zone_id INTEGER NOT NULL,
    quantity REAL NOT NULL,
    moved_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    moved_by TEXT,
    reason TEXT,
    FOREIGN KEY (batch_id) REFERENCES batches(id),
    FOREIGN KEY (from_zone_id) REFERENCES storage_zones(id),
    FOREIGN KEY (to_zone_id) REFERENCES storage_zones(id)
);
