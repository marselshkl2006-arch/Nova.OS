#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QInputDialog>
#include <QFileDialog>
#include <QMenuBar>
#include <QToolBar>
#include <QStatusBar>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGroupBox>
#include <QHeaderView>
#include <QChart>
#include <QChartView>
#include <QBarSet>
#include <QBarSeries>
#include <QBarCategoryAxis>
#include <QValueAxis>
#include <QtCharts>

using namespace QtCharts;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_db(new Database(this))
    , m_refreshTimer(new QTimer(this))
{
    // Инициализация БД
    if (!m_db->initialize()) {
        QMessageBox::critical(this, "Ошибка", "Не удалось инициализировать базу данных!");
        exit(1);
    }

    // Создание моделей
    m_chemicalModel = new ChemicalModel(m_db, this);
    m_storageModel = new StorageModel(m_db, this);

    // Настройка UI
    ui->setupUi(this);
    setupUI();
    setupConnections();
    createMenuBar();
    createToolBar();
    createStatusBar();

    // Настройка таймера автообновления
    m_refreshTimer->setInterval(30000); // 30 секунд
    connect(m_refreshTimer, &QTimer::timeout, this, &MainWindow::updateDashboard);
    m_refreshTimer->start();

    // Первоначальное обновление
    updateDashboard();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::setupUI()
{
    setWindowTitle("Система управления химической лабораторией");
    setWindowIcon(QIcon(":/icons/flask.svg"));
    resize(1200, 800);

    // Центральный виджет с вкладками
    QTabWidget *tabWidget = new QTabWidget(this);
    setCentralWidget(tabWidget);

    // Вкладка 1: Химикаты
    QWidget *chemicalsTab = new QWidget;
    QVBoxLayout *chemicalsLayout = new QVBoxLayout(chemicalsTab);
    
    // Кнопки управления химикатами
    QHBoxLayout *chemicalButtonsLayout = new QHBoxLayout;
    QPushButton *btnAddChemical = new QPushButton("Добавить химикат");
    QPushButton *btnEditChemical = new QPushButton("Редактировать");
    QPushButton *btnDeleteChemical = new QPushButton("Удалить");
    QPushButton *btnRefreshChemicals = new QPushButton("Обновить");
    
    chemicalButtonsLayout->addWidget(btnAddChemical);
    chemicalButtonsLayout->addWidget(btnEditChemical);
    chemicalButtonsLayout->addWidget(btnDeleteChemical);
    chemicalButtonsLayout->addWidget(btnRefreshChemicals);
    chemicalButtonsLayout->addStretch();
    
    // Таблица химикатов
    QTableView *chemicalsTable = new QTableView;
    chemicalsTable->setModel(m_chemicalModel);
    chemicalsTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    chemicalsTable->setSelectionMode(QAbstractItemView::SingleSelection);
    chemicalsTable->horizontalHeader()->setStretchLastSection(true);
    chemicalsTable->setSortingEnabled(true);
    
    chemicalsLayout->addLayout(chemicalButtonsLayout);
    chemicalsLayout->addWidget(chemicalsTable);
    tabWidget->addTab(chemicalsTab, "Химикаты");

    // Вкладка 2: Зоны хранения
    QWidget *zonesTab = new QWidget;
    QVBoxLayout *zonesLayout = new QVBoxLayout(zonesTab);
    
    QHBoxLayout *zoneButtonsLayout = new QHBoxLayout;
    QPushButton *btnAddZone = new QPushButton("Добавить зону");
    QPushButton *btnEditZone = new QPushButton("Редактировать");
    QPushButton *btnDeleteZone = new QPushButton("Удалить");
    
    zoneButtonsLayout->addWidget(btnAddZone);
    zoneButtonsLayout->addWidget(btnEditZone);
    zoneButtonsLayout->addWidget(btnDeleteZone);
    zoneButtonsLayout->addStretch();
    
    QTableView *zonesTable = new QTableView;
    zonesTable->setModel(m_storageModel);
    zonesTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    zonesTable->horizontalHeader()->setStretchLastSection(true);
    
    zonesLayout->addLayout(zoneButtonsLayout);
    zonesLayout->addWidget(zonesTable);
    tabWidget->addTab(zonesTab, "Зоны хранения");

    // Вкладка 3: Безопасность
    QWidget *safetyTab = new QWidget;
    QVBoxLayout *safetyLayout = new QVBoxLayout(safetyTab);
    
    QGroupBox *safetyAlertsGroup = new QGroupBox("Оповещения безопасности");
    QVBoxLayout *alertsLayout = new QVBoxLayout(safetyAlertsGroup);
    
    QLabel *lblExpiring = new QLabel;
    QLabel *lblOverloaded = new QLabel;
    QLabel *lblTemperature = new QLabel;
    
    alertsLayout->addWidget(lblExpiring);
    alertsLayout->addWidget(lblOverloaded);
    alertsLayout->addWidget(lblTemperature);
    
    QPushButton *btnRunSafetyCheck = new QPushButton("Запустить проверку безопасности");
    QPushButton *btnGenerateReport = new QPushButton("Создать отчет");
    
    safetyLayout->addWidget(safetyAlertsGroup);
    safetyLayout->addWidget(btnRunSafetyCheck);
    safetyLayout->addWidget(btnGenerateReport);
    safetyLayout->addStretch();
    
    tabWidget->addTab(safetyTab, "Безопасность");

    // Вкладка 4: Статистика
    QWidget *statsTab = new QWidget;
    QVBoxLayout *statsLayout = new QVBoxLayout(statsTab);
    
    QGroupBox *statsGroup = new QGroupBox("Статистика лаборатории");
    QGridLayout *statsGrid = new QGridLayout(statsGroup);
    
    QLabel *lblTotalChemicals = new QLabel;
    QLabel *lblTotalQuantity = new QLabel;
    QLabel *lblTotalZones = new QLabel;
    QLabel *lblAvgDanger = new QLabel;
    
    statsGrid->addWidget(new QLabel("Всего химикатов:"), 0, 0);
    statsGrid->addWidget(lblTotalChemicals, 0, 1);
    statsGrid->addWidget(new QLabel("Общее количество:"), 1, 0);
    statsGrid->addWidget(lblTotalQuantity, 1, 1);
    statsGrid->addWidget(new QLabel("Зон хранения:"), 2, 0);
    statsGrid->addWidget(lblTotalZones, 2, 1);
    statsGrid->addWidget(new QLabel("Средний класс опасности:"), 3, 0);
    statsGrid->addWidget(lblAvgDanger, 3, 1);
    
    // График распределения по классам опасности
    QChartView *chartView = new QChartView;
    chartView->setRenderHint(QPainter::Antialiasing);
    
    statsLayout->addWidget(statsGroup);
    statsLayout->addWidget(chartView);
    
    tabWidget->addTab(statsTab, "Статистика");

    // Сохранение ссылок на виджеты
    ui->chemicalsTable = chemicalsTable;
    ui->zonesTable = zonesTable;
    ui->btnAddChemical = btnAddChemical;
    ui->btnEditChemical = btnEditChemical;
    ui->btnDeleteChemical = btnDeleteChemical;
    ui->btnAddZone = btnAddZone;
    ui->btnEditZone = btnEditZone;
    ui->btnDeleteZone = btnDeleteZone;
    ui->btnRunSafetyCheck = btnRunSafetyCheck;
    ui->btnGenerateReport = btnGenerateReport;
    ui->lblExpiring = lblExpiring;
    ui->lblOverloaded = lblOverloaded;
    ui->lblTemperature = lblTemperature;
    ui->lblTotalChemicals = lblTotalChemicals;
    ui->lblTotalQuantity = lblTotalQuantity;
    ui->lblTotalZones = lblTotalZones;
    ui->lblAvgDanger = lblAvgDanger;
    ui->chartView = chartView;
}

void MainWindow::setupConnections()
{
    connect(ui->btnAddChemical, &QPushButton::clicked, this, &MainWindow::onAddChemical);
    connect(ui->btnEditChemical, &QPushButton::clicked, this, &MainWindow::onEditChemical);
    connect(ui->btnDeleteChemical, &QPushButton::clicked, this, &MainWindow::onDeleteChemical);
    connect(ui->btnAddZone, &QPushButton::clicked, this, &MainWindow::onAddZone);
    connect(ui->btnRunSafetyCheck, &QPushButton::clicked, this, &MainWindow::onRunSafetyCheck);
    connect(ui->btnGenerateReport, &QPushButton::clicked, this, &MainWindow::onGenerateReport);
}

void MainWindow::createMenuBar()
{
    QMenu *fileMenu = menuBar()->addMenu("Файл");
    QAction *actExport = fileMenu->addAction("Экспорт данных...");
    QAction *actBackup = fileMenu->addAction("Создать резервную копию");
    fileMenu->addSeparator();
    QAction *actExit = fileMenu->addAction("Выход");
    
    QMenu *helpMenu = menuBar()->addMenu("Помощь");
    QAction *actAbout = helpMenu->addAction("О программе");
    
    connect(actExit, &QAction::triggered, this, &QWidget::close);
    connect(actAbout, &QAction::triggered, []() {
        QMessageBox::about(nullptr, "О программе", 
            "Система управления химической лабораторией\nВерсия 1.0.0\n\n"
            "Программа для учета химикатов, управления зонами хранения\n"
            "и мониторинга безопасности химической лаборатории.");
    });
}

void MainWindow::createToolBar()
{
    QToolBar *toolBar = addToolBar("Основные действия");
    toolBar->addAction(QIcon(":/icons/add.svg"), "Добавить химикат", this, &MainWindow::onAddChemical);
    toolBar->addAction(QIcon(":/icons/warning.svg"), "Проверить безопасность", this, &MainWindow::onRunSafetyCheck);
    toolBar->addAction(QIcon(":/icons/refresh.svg"), "Обновить", this, &MainWindow::onRefreshData);
}

void MainWindow::createStatusBar()
{
    statusBar()->showMessage("Готово");
}

void MainWindow::onAddChemical()
{
    showChemicalDialog();
}

void MainWindow::onEditChemical()
{
    QModelIndexList selected = ui->chemicalsTable->selectionModel()->selectedRows();
    if (selected.isEmpty()) {
        QMessageBox::warning(this, "Внимание", "Выберите химикат для редактирования");
        return;
    }
    
    int id = m_chemicalModel->getChemicalAt(selected.first().row()).id;
    showChemicalDialog(id);
}

void MainWindow::showChemicalDialog(int id)
{
    // Создание диалога добавления/редактирования химиката
    QDialog dialog(this);
    dialog.setWindowTitle(id == -1 ? "Добавить химикат" : "Редактировать химикат");
    
    QFormLayout layout(&dialog);
    
    QLineEdit *nameEdit = new QLineEdit;
    QLineEdit *formulaEdit = new QLineEdit;
    QComboBox *typeCombo = new QComboBox;
    typeCombo->addItems({"acid", "base", "organic", "inorganic", "oxide"});
    
    QSpinBox *dangerSpin = new QSpinBox;
    dangerSpin->setRange(0, 5);
    
    QDoubleSpinBox *tempSpin = new QDoubleSpinBox;
    tempSpin->setRange(-273, 1000);
    tempSpin->setSuffix("°C");
    
    QSpinBox *shelfSpin = new QSpinBox;
    shelfSpin->setRange(1, 999);
    shelfSpin->setSuffix(" месяцев");
    
    QDoubleSpinBox *quantitySpin = new QDoubleSpinBox;
    quantitySpin->setRange(0, 1000000);
    
    QComboBox *unitCombo = new QComboBox;
    unitCombo->addItems({"г", "мл", "л", "кг"});
    
    QLineEdit *containerEdit = new QLineEdit;
    
    layout.addRow("Название:", nameEdit);
    layout.addRow("Формула:", formulaEdit);
    layout.addRow("Тип:", typeCombo);
    layout.addRow("Класс опасности (0-5):", dangerSpin);
    layout.addRow("Температура хранения:", tempSpin);
    layout.addRow("Срок годности:", shelfSpin);
    layout.addRow("Количество:", quantitySpin);
    layout.addRow("Единица измерения:", unitCombo);
    layout.addRow("Тип контейнера:", containerEdit);
    
    QDialogButtonBox buttons(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
    layout.addRow(&buttons);
    
    connect(&buttons, &QDialogButtonBox::accepted, &dialog, &QDialog::accept);
    connect(&buttons, &QDialogButtonBox::rejected, &dialog, &QDialog::reject);
    
    // Если редактирование, загружаем данные
    if (id != -1) {
        Chemical chem = m_db->getChemicalById(id);
        nameEdit->setText(chem.name);
        formulaEdit->setText(chem.formula);
        typeCombo->setCurrentText(chem.type);
        dangerSpin->setValue(chem.dangerClass);
        tempSpin->setValue(chem.storageTemp);
        shelfSpin->setValue(chem.shelfLife);
        quantitySpin->setValue(chem.quantity);
        unitCombo->setCurrentText(chem.unit);
        containerEdit->setText(chem.container);
    }
    
    if (dialog.exec() == QDialog::Accepted) {
        Chemical chem;
        if (id != -1) chem.id = id;
        chem.name = nameEdit->text();
        chem.formula = formulaEdit->text();
        chem.type = typeCombo->currentText();
        chem.dangerClass = dangerSpin->value();
        chem.storageTemp = tempSpin->value();
        chem.shelfLife = shelfSpin->value();
        chem.quantity = quantitySpin->value();
        chem.unit = unitCombo->currentText();
        chem.container = containerEdit->text();
        
        bool success = id == -1 ? m_db->addChemical(chem) : true; // TODO: update method
        
        if (success) {
            m_chemicalModel->refresh();
            statusBar()->showMessage("Химикат сохранен", 3000);
        } else {
            QMessageBox::critical(this, "Ошибка", "Не удалось сохранить химикат");
        }
    }
}

void MainWindow::updateDashboard()
{
    // Обновление статистики
    auto stats = m_db->getStatistics();
    ui->lblTotalChemicals->setText(stats["total_chemicals"].toString());
    ui->lblTotalQuantity->setText(QString("%1 ед.").arg(stats["total_quantity"].toString()));
    ui->lblTotalZones->setText(stats["total_zones"].toString());
    
    // Проверка безопасности
    auto expiring = m_db->getExpiringBatches(7);
    if (!expiring.isEmpty()) {
        ui->lblExpiring->setText(
            QString("<font color='red'>⚠ %1 партий истекает в течение недели</font>")
            .arg(expiring.size())
        );
    } else {
        ui->lblExpiring->setText("<font color='green'>✓ Нет срочно истекающих партий</font>");
    }
    
    // Обновление графика
    auto chemicals = m_db->getAllChemicals();
    QMap<int, int> dangerDistribution;
    double totalDanger = 0;
    
    for (const auto &chem : chemicals) {
        dangerDistribution[chem.dangerClass]++;
        totalDanger += chem.dangerClass;
    }
    
    if (!chemicals.isEmpty()) {
        double avgDanger = totalDanger / chemicals.size();
        ui->lblAvgDanger->setText(QString::number(avgDanger, 'f', 2));
    }
    
    // Создание графика
    QBarSet *set = new QBarSet("Количество химикатов");
    QStringList categories;
    
    for (int i = 0; i <= 5; i++) {
        *set << dangerDistribution[i];
        categories << QString("Класс %1").arg(i);
    }
    
    QBarSeries *series = new QBarSeries();
    series->append(set);
    
    QChart *chart = new QChart();
    chart->addSeries(series);
    chart->setTitle("Распределение химикатов по классам опасности");
    chart->setAnimationOptions(QChart::SeriesAnimations);
    
    QBarCategoryAxis *axisX = new QBarCategoryAxis();
    axisX->append(categories);
    chart->addAxis(axisX, Qt::AlignBottom);
    series->attachAxis(axisX);
    
    QValueAxis *axisY = new QValueAxis();
    chart->addAxis(axisY, Qt::AlignLeft);
    series->attachAxis(axisY);
    
    chart->legend()->setVisible(true);
    chart->legend()->setAlignment(Qt::AlignBottom);
    
    ui->chartView->setChart(chart);
}