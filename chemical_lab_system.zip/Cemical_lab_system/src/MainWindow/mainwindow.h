#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTabWidget>
#include <QTableView>
#include <QPushButton>
#include <QLabel>
#include <QProgressBar>
#include <QTimer>
#include "chemicalmodel.h"
#include "storagemodel.h"
#include "database.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onAddChemical();
    void onEditChemical();
    void onDeleteChemical();
    void onAddZone();
    void onRunSafetyCheck();
    void onGenerateReport();
    void onRefreshData();
    void updateDashboard();

private:
    Ui::MainWindow *ui;
    Database *m_db;
    ChemicalModel *m_chemicalModel;
    StorageModel *m_storageModel;
    QTimer *m_refreshTimer;

    void setupUI();
    void setupConnections();
    void createMenuBar();
    void createToolBar();
    void createStatusBar();
    void showChemicalDialog(int id = -1);
    void showZoneDialog(int id = -1);
};

#endif // MAINWINDOW_H