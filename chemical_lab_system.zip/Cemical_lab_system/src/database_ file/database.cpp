#include "database.h"
#include <QDir>
#include <QDebug>
#include <QDate>

Database::Database(QObject *parent) : QObject(parent)
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("data/laboratory.db");
}

Database::~Database()
{
    if (db.isOpen()) {
        db.close();
    }
}

bool Database::initialize()
{
    if (!db.open()) {
        qWarning() << "Cannot open database:" << db.lastError().text();
        return false;
    }

    if (!createTables()) {
        return false;
    }

    // Проверяем есть ли данные
    QSqlQuery checkQuery("SELECT COUNT(*) FROM chemicals");
    if (checkQuery.next() && checkQuery.value(0).toInt() == 0) {
        populateTestData();
    }

    return true;
}

bool Database::isOpen() const
{
    return db.isOpen();
}

bool Database::createTables()
{
    QSqlQuery query;

    // Таблица химикатов
    if (!query.exec(
        "CREATE TABLE IF NOT EXISTS chemicals ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "name TEXT NOT NULL,"
        "formula TEXT,"
        "type TEXT,"
        "danger_class INTEGER CHECK(danger_class BETWEEN 0 AND 5),"
        "storage_temp REAL NOT NULL,"
        "shelf_life_months INTEGER,"
        "quantity REAL DEFAULT 0,"
        "unit TEXT DEFAULT 'г',"
        "container TEXT,"
        "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)"
    )) {
        qWarning() << "Failed to create chemicals table:" << query.lastError().text();
        return false;
    }

    // Таблица зон хранения
    if (!query.exec(
        "CREATE TABLE IF NOT EXISTS storage_zones ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "name TEXT UNIQUE NOT NULL,"
        "temperature REAL NOT NULL,"
        "max_capacity REAL NOT NULL,"
        "current_load REAL DEFAULT 0,"
        "zone_type TEXT,"
        "description TEXT)"
    )) {
        qWarning() << "Failed to create storage_zones table:" << query.lastError().text();
        return false;
    }

    // Таблица партий
    if (!query.exec(
        "CREATE TABLE IF NOT EXISTS batches ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "chemical_id INTEGER NOT NULL,"
        "zone_id INTEGER,"
        "quantity REAL NOT NULL CHECK(quantity > 0),"
        "production_date TEXT,"
        "expiration_date TEXT,"
        "supplier TEXT,"
        "FOREIGN KEY (chemical_id) REFERENCES chemicals(id) ON DELETE CASCADE,"
        "FOREIGN KEY (zone_id) REFERENCES storage_zones(id))"
    )) {
        qWarning() << "Failed to create batches table:" << query.lastError().text();
        return false;
    }

    return true;
}

bool Database::populateTestData()
{
    QSqlQuery query;

    // Химикаты
    QStringList chemicals = {
        "('Серная кислота', 'H2SO4', 'acid', 1, 20.0, 36, 5000.0, 'мл', 'Стеклянная банка')",
        "('Соляная кислота', 'HCl', 'acid', 1, 20.0, 24, 3000.0, 'мл', 'Полиэтилен')",
        "('Гидроксид натрия', 'NaOH', 'base', 2, 25.0, 24, 2000.0, 'г', 'Пластик')",
        "('Этанол', 'C2H5OH', 'organic', 3, 15.0, 12, 10000.0, 'мл', 'Стекло')",
        "('Ацетон', 'C3H6O', 'organic', 3, 20.0, 24, 5000.0, 'мл', 'Металл')",
        "('Перекись водорода', 'H2O2', 'oxide', 1, 4.0, 6, 2000.0, 'мл', 'Темное стекло')"
    };

    if (!query.exec("INSERT INTO chemicals (name, formula, type, danger_class, storage_temp, "
                   "shelf_life_months, quantity, unit, container) VALUES " + chemicals.join(", "))) {
        qWarning() << "Failed to insert test chemicals:" << query.lastError().text();
        return false;
    }

    // Зоны хранения
    QStringList zones = {
        "('Холодильник кислот', 4.0, 50.0, 0, 'refrigerator', 'Для кислот и термочувствительных веществ')",
        "('Морозильник', -18.0, 30.0, 0, 'freezer', 'Для длительного хранения')",
        "('Основное хранилище', 20.0, 200.0, 0, 'room_temp', 'Основное помещение лаборатории')",
        "('Пожароопасная зона', 15.0, 40.0, 0, 'flammable', 'Для легковоспламеняющихся веществ')",
        "('Щелочная зона', 25.0, 60.0, 0, 'base', 'Отдельное хранение щелочей')"
    };

    if (!query.exec("INSERT INTO storage_zones (name, temperature, max_capacity, current_load, "
                   "zone_type, description) VALUES " + zones.join(", "))) {
        qWarning() << "Failed to insert test zones:" << query.lastError().text();
        return false;
    }

    return true;
}

QVector<Chemical> Database::getAllChemicals()
{
    QVector<Chemical> chemicals;
    QSqlQuery query("SELECT id, name, formula, type, danger_class, storage_temp, "
                   "shelf_life_months, quantity, unit, container, created_at "
                   "FROM chemicals ORDER BY name");

    while (query.next()) {
        Chemical chem;
        chem.id = query.value(0).toInt();
        chem.name = query.value(1).toString();
        chem.formula = query.value(2).toString();
        chem.type = query.value(3).toString();
        chem.dangerClass = query.value(4).toInt();
        chem.storageTemp = query.value(5).toDouble();
        chem.shelfLife = query.value(6).toInt();
        chem.quantity = query.value(7).toDouble();
        chem.unit = query.value(8).toString();
        chem.container = query.value(9).toString();
        chem.createdAt = query.value(10).toString();
        chemicals.append(chem);
    }

    return chemicals;
}

Chemical Database::getChemicalById(int id)
{
    Chemical chem;
    QSqlQuery query;
    query.prepare("SELECT id, name, formula, type, danger_class, storage_temp, "
                  "shelf_life_months, quantity, unit, container, created_at "
                  "FROM chemicals WHERE id = :id");
    query.bindValue(":id", id);

    if (query.exec() && query.next()) {
        chem.id = query.value(0).toInt();
        chem.name = query.value(1).toString();
        chem.formula = query.value(2).toString();
        chem.type = query.value(3).toString();
        chem.dangerClass = query.value(4).toInt();
        chem.storageTemp = query.value(5).toDouble();
        chem.shelfLife = query.value(6).toInt();
        chem.quantity = query.value(7).toDouble();
        chem.unit = query.value(8).toString();
        chem.container = query.value(9).toString();
        chem.createdAt = query.value(10).toString();
    }

    return chem;
}

bool Database::addChemical(const Chemical &chem)
{
    QSqlQuery query;
    query.prepare("INSERT INTO chemicals (name, formula, type, danger_class, storage_temp, "
                  "shelf_life_months, quantity, unit, container) "
                  "VALUES (:name, :formula, :type, :danger_class, :storage_temp, "
                  ":shelf_life, :quantity, :unit, :container)");
    
    query.bindValue(":name", chem.name);
    query.bindValue(":formula", chem.formula);
    query.bindValue(":type", chem.type);
    query.bindValue(":danger_class", chem.dangerClass);
    query.bindValue(":storage_temp", chem.storageTemp);
    query.bindValue(":shelf_life", chem.shelfLife);
    query.bindValue(":quantity", chem.quantity);
    query.bindValue(":unit", chem.unit);
    query.bindValue(":container", chem.container);

    return query.exec();
}

QVector<StorageZone> Database::getAllStorageZones()
{
    QVector<StorageZone> zones;
    QSqlQuery query("SELECT id, name, temperature, max_capacity, current_load, "
                   "zone_type, description FROM storage_zones ORDER BY name");

    while (query.next()) {
        StorageZone zone;
        zone.id = query.value(0).toInt();
        zone.name = query.value(1).toString();
        zone.temperature = query.value(2).toDouble();
        zone.maxCapacity = query.value(3).toDouble();
        zone.currentLoad = query.value(4).toDouble();
        zone.zoneType = query.value(5).toString();
        zone.description = query.value(6).toString();
        zones.append(zone);
    }

    return zones;
}

QVector<Batch> Database::getExpiringBatches(int daysThreshold)
{
    QVector<Batch> batches;
    QSqlQuery query;
    query.prepare(
        "SELECT b.id, b.chemical_id, b.zone_id, b.quantity, "
        "b.expiration_date, julianday(b.expiration_date) - julianday('now') as days_left "
        "FROM batches b "
        "WHERE days_left <= :threshold AND days_left >= 0 "
        "ORDER BY days_left"
    );
    query.bindValue(":threshold", daysThreshold);

    if (query.exec()) {
        while (query.next()) {
            Batch batch;
            batch.id = query.value(0).toInt();
            batch.chemicalId = query.value(1).toInt();
            batch.zoneId = query.value(2).toInt();
            batch.quantity = query.value(3).toDouble();
            batch.expirationDate = query.value(4).toString();
            batches.append(batch);
        }
    }

    return batches;
}

QMap<QString, QVariant> Database::getStatistics()
{
    QMap<QString, QVariant> stats;
    QSqlQuery query;

    // Количество химикатов
    if (query.exec("SELECT COUNT(*) FROM chemicals") && query.next()) {
        stats["total_chemicals"] = query.value(0);
    }

    // Суммарное количество
    if (query.exec("SELECT SUM(quantity) FROM chemicals") && query.next()) {
        stats["total_quantity"] = query.value(0);
    }

    // Количество зон
    if (query.exec("SELECT COUNT(*) FROM storage_zones") && query.next()) {
        stats["total_zones"] = query.value(0);
    }

    // Истекающие партии
    if (query.exec("SELECT COUNT(*) FROM batches WHERE "
                  "julianday(expiration_date) - julianday('now') <= 7") && query.next()) {
        stats["expiring_soon"] = query.value(0);
    }

    return stats;
}