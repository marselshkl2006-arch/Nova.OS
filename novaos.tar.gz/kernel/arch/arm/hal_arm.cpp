// kernel/arch/arm/hal_arm.cpp
#include "../hal.h"
#include "console.h"

namespace HAL {
    // ARM-специфичная реализация
    void arm_initialize() {
        Console::write("🔧 ARM HAL: Initializing...\n");
        
        // Инициализация GIC, timer и т.д.
        Console::write("✅ ARM HAL Ready\n");
    }
    
    void arm_enable_interrupts() {
        asm volatile("cpsie i"); // Enable IRQ
    }
    
    void arm_disable_interrupts() {
        asm volatile("cpsid i"); // Disable IRQ
    }
}