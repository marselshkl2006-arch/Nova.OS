// kernel/hal.h
#pragma once
#include <stdint.h>

// Архитектуры процессоров
enum class Architecture {
    X86,
    X64, 
    ARM32,
    ARM64,
    RISCV64
};

// Типы устройств
enum class DeviceType {
    DESKTOP,
    PHONE,
    TABLET,
    EMBEDDED
};

namespace HAL {
    // Инициализация HAL
    void initialize();
    
    // Информация о системе
    Architecture get_architecture();
    DeviceType get_device_type();
    const char* get_arch_name();
    const char* get_device_name();
    
    // Управление памятью
    void* allocate_physical_page();
    void free_physical_page(void* page);
    uint32_t get_page_size();
    
    // Прерывания
    void enable_interrupts();
    void disable_interrupts();
    void register_interrupt_handler(uint8_t interrupt, void (*handler)());
    
    // Таймер
    void initialize_timer(uint32_t frequency_hz);
    uint64_t get_system_ticks();
    
    // Ввод/вывод
    void initialize_console();
    void put_char(char c);
    char get_char();
    
    // Графика (универсальный фреймбуфер)
    struct FrameBuffer {
        void* address;
        uint32_t width;
        uint32_t height;
        uint32_t pitch;
        uint32_t bpp; // bits per pixel
    };
    
    FrameBuffer get_frame_buffer();
}