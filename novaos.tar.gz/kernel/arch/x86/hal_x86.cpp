#include "hal.h"  // Исправляем путь

// x86-специфичные реализации
namespace HAL {
    void x86_initialize() {
        // Пустая реализация
    }
    
    void x86_enable_interrupts() { 
        asm("sti"); 
    }
    
    void x86_disable_interrupts() { 
        asm("cli"); 
    }
    
    uint64_t x86_get_system_ticks() { 
        return 0; 
    }
}
