// kernel/ata.h
#pragma once
#include <stdint.h>

namespace ATA {
    void initialize();
    bool read_sectors(uint32_t lba, uint8_t sector_count, void* buffer);
    bool write_sectors(uint32_t lba, uint8_t sector_count, const void* buffer);
    void identify_drive();
}
