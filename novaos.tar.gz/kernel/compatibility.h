// kernel/compatibility.h
#pragma once
#include <stdint.h>

namespace Compatibility {
    // Поддержка форматов исполняемых файлов
    enum BinaryFormat {
        ELF_LINUX,      // Linux ELF
        PE_WINDOWS,     // Windows PE
        MACH_OSX,       // macOS Mach-O
        NOVA_NATIVE     // Нативный формат Nova OS
    };
    
    // Системные вызовы совместимости
    enum SyscallAPI {
        LINUX_API = 0,
        WINDOWS_API = 1,
        POSIX_API = 2
    };
    
    void initialize();
    bool load_executable(const char* filename, BinaryFormat format);
    void set_compatibility_layer(SyscallAPI api);
}
