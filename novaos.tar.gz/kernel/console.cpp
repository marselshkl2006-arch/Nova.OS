// kernel/console.cpp
#include "console.h"

static uint16_t* const VGA_MEMORY = (uint16_t*)0xB8000;

namespace Console {
    static size_t terminal_row = 0;
    static size_t terminal_column = 0;
    static uint8_t terminal_color = 0x0F;
    
    void initialize() {
        clear();
    }
    
    void clear() {
        for (size_t y = 0; y < 25; y++) {
            for (size_t x = 0; x < 80; x++) {
                const size_t index = y * 80 + x;
                VGA_MEMORY[index] = (terminal_color << 8) | ' ';
            }
        }
        terminal_row = 0;
        terminal_column = 0;
    }
    
    void write_char(char c) {
        if (c == '\n') {
            terminal_column = 0;
            if (++terminal_row == 25) terminal_row = 0;
            return;
        }
        
        const size_t index = terminal_row * 80 + terminal_column;
        VGA_MEMORY[index] = (terminal_color << 8) | c;
        
        if (++terminal_column == 80) {
            terminal_column = 0;
            if (++terminal_row == 25) terminal_row = 0;
        }
    }
    
    void write(const char* str) {
        for (size_t i = 0; str[i] != '\0'; i++) {
            write_char(str[i]);
        }
    }
    
    void write_number(uint32_t num) {  
        if (num == 0) {
            write_char('0');
            return;
        }
        
        char buffer[32];
        int i = 0;
        
        while (num > 0) {
            buffer[i++] = '0' + (num % 10);
            num /= 10;
        }
        
        for (int j = i - 1; j >= 0; j--) {
            write_char(buffer[j]);
        }
    }
}