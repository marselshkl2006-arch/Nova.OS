// kernel/console.h
#pragma once
#include <stdint.h>
#include <stddef.h>

namespace Console {
    void initialize();
    void write(const char* str);
    void write_char(char c);
    void write_number(uint32_t num);  
    void clear();
}