// kernel/filesystem.cpp
#include "filesystem.h"
#include "memory.h"
#include "console.h"
#include "string.h"

#define MAX_FILES 100
#define FILE_DATA_SIZE 8192 // 8KB per file

static File files[MAX_FILES];
static uint32_t file_count = 0;

namespace FileSystem {
    void initialize() {
        file_count = 0;
        // Создаем системные файлы
        create_file("readme.txt");
        create_file("system.cfg");
        
        Console::write("📁 File system initialized\n");
    }
    
    File* open(const char* filename) {
        for (uint32_t i = 0; i < file_count; i++) {
            if (::strcmp(files[i].name, filename) == 0) {  // Используем глобальный strcmp
                files[i].position = 0;
                return &files[i];
            }
        }
        return nullptr;
    }
    
    void close(File* file) {
        // Пока ничего не делаем
        (void)file;
    }
    
    size_t read(File* file, void* buffer, size_t size) {
        if (!file || !buffer) return 0;
        
        size_t bytes_to_read = size;
        if (file->position + bytes_to_read > file->size) {
            bytes_to_read = file->size - file->position;
        }
        
        // Используем глобальный memcpy
        ::memcpy(buffer, file->data + file->position, bytes_to_read);
        file->position += bytes_to_read;
        
        return bytes_to_read;
    }
    
    size_t write(File* file, const void* buffer, size_t size) {
        if (!file || !buffer) return 0;
        
        // Проверяем, нужно ли расширить файл
        if (file->position + size > file->size) {
            // В нашей простой ФС файлы имеют фиксированный размер
            if (file->position + size > FILE_DATA_SIZE) {
                size = FILE_DATA_SIZE - file->position;
            }
            file->size = file->position + size;
        }
        
        // Используем глобальный memcpy
        ::memcpy(file->data + file->position, buffer, size);
        file->position += size;
        
        return size;
    }
    
    void create_file(const char* filename) {
        if (file_count >= MAX_FILES) {
            Console::write("❌ Cannot create file: maximum files reached\n");
            return;
        }
        
        File* file = &files[file_count];
        
        // Используем глобальные функции string
        ::strcpy(file->name, filename);
        
        file->size = 0;
        file->position = 0;
        file->data = (uint8_t*)MemoryManager::malloc(FILE_DATA_SIZE);
        
        if (file->data) {
            // Инициализируем нулями
            ::memset(file->data, 0, FILE_DATA_SIZE);
            file_count++;
            Console::write("✅ Created file: ");
            Console::write(filename);
            Console::write("\n");
        } else {
            Console::write("❌ Failed to allocate memory for file: ");
            Console::write(filename);
            Console::write("\n");
        }
    }
    
    void list_files() {
        if (file_count == 0) {
            Console::write("No files found\n");
            return;
        }
        
        Console::write("Files:\n");
        for (uint32_t i = 0; i < file_count; i++) {
            Console::write("  ");
            Console::write(files[i].name);
            Console::write(" (");
            Console::write_number(files[i].size);
            Console::write(" bytes)\n");
        }
    }
    
    void write_text_to_file(const char* filename, const char* text) {
        File* file = open(filename);
        if (file) {
            write(file, text, ::strlen(text));  // Используем глобальный strlen
        }
    }
    
    void read_and_print_file(const char* filename) {
        File* file = open(filename);
        if (file) {
            char buffer[256];
            size_t bytes_read = read(file, buffer, sizeof(buffer) - 1);
            if (bytes_read > 0) {
                buffer[bytes_read] = '\0';
                Console::write("Contents of ");
                Console::write(filename);
                Console::write(": ");
                Console::write(buffer);
                Console::write("\n");
            } else {
                Console::write("File ");
                Console::write(filename);
                Console::write(" is empty\n");
            }
        } else {
            Console::write("File not found: ");
            Console::write(filename);
            Console::write("\n");
        }
    }
}