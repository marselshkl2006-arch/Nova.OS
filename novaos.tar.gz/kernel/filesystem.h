// kernel/filesystem.h
#pragma once
#include <stdint.h>
#include <stddef.h>

struct File {
    char name[32];
    uint32_t size;
    uint32_t position;
    uint8_t* data;
};

namespace FileSystem {
    void initialize();
    File* open(const char* filename);
    void close(File* file);
    size_t read(File* file, void* buffer, size_t size);
    size_t write(File* file, const void* buffer, size_t size);
    void create_file(const char* filename);
    void list_files();
    
    // ДОБАВЛЯЕМ ОБЪЯВЛЕНИЯ НОВЫХ ФУНКЦИЙ
    void write_text_to_file(const char* filename, const char* text);
    void read_and_print_file(const char* filename);
}