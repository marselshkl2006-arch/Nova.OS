// kernel/gaming.h
#pragma once

#include <stdint.h>


namespace Gaming {
    // Графические API
    enum GraphicsAPI {
        OPENGL,
        VULKAN,
        DIRECTX11,      // Через трансляцию
        DIRECTX12       // Через трансляцию
    };
    
    struct GameProfile {
        char name[64];
        GraphicsAPI preferred_api;
        uint32_t required_ram;
        bool high_performance_mode;
    };
    
    void initialize();
    bool set_graphics_mode(GraphicsAPI api, bool exclusive);
    void optimize_for_game(const GameProfile& profile);
    
    // Игровые сервисы
    void enable_game_mode();
    void disable_game_mode();
}