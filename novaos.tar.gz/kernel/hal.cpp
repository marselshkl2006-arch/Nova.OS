#include "hal.h"
#include "console.h"

namespace HAL {
    void initialize() {
        Console::write("🔧 HAL initialized\n");
    }
    
    Architecture get_architecture() { return Architecture::X86; }
    DeviceType get_device_type() { return DeviceType::DESKTOP; }
    const char* get_arch_name() { return "x86"; }
    const char* get_device_name() { return "Desktop"; }
    
    void* allocate_physical_page() { return nullptr; }
    void free_physical_page(void* page) {}
    uint32_t get_page_size() { return 4096; }
    
    void enable_interrupts() { asm("sti"); }
    void disable_interrupts() { asm("cli"); }
    void register_interrupt_handler(uint8_t interrupt, void (*handler)()) {}
    
    void initialize_timer(uint32_t frequency_hz) {}
    uint64_t get_system_ticks() { return 0; }
    
    void initialize_console() {}
    void put_char(char c) {}
    char get_char() { return 0; }
    
    FrameBuffer get_frame_buffer() { return FrameBuffer{nullptr, 0, 0, 0, 0}; }
}
