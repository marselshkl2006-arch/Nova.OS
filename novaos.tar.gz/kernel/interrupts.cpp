// kernel/interrupts.cpp
#include "interrupts.h"
#include "console.h"
#include <stdint.h>

struct IDTEntry {
    uint16_t offset_low;
    uint16_t selector;
    uint8_t zero;
    uint8_t type_attr;
    uint16_t offset_high;
} __attribute__((packed));

struct IDTPtr {
    uint16_t limit;
    uint32_t base;
} __attribute__((packed));

static IDTEntry idt[256];
static void (*interrupt_handlers[256])();

// Объявляем функции ДО их использования
extern "C" void default_handler();
extern "C" void interrupt_handler(uint32_t interrupt);
extern "C" void load_idt(uint32_t);
static void set_idt_entry(uint8_t num, uint32_t offset, uint16_t selector, uint8_t flags);

namespace Interrupts {
    void initialize() {
        IDTPtr idt_ptr;
        idt_ptr.limit = sizeof(idt) - 1;
        idt_ptr.base = (uint32_t)&idt;
        
        // Заполняем IDT
        for (int i = 0; i < 256; i++) {
            set_idt_entry(i, (uint32_t)default_handler, 0x08, 0x8E);
            interrupt_handlers[i] = nullptr;
        }
        
        // Перепрограммируем PIC
        asm volatile(
            "mov $0x11, %al\n"
            "out %al, $0x20\n"
            "out %al, $0xA0\n"
            "mov $0x20, %al\n"
            "out %al, $0x21\n"
            "mov $0x28, %al\n"
            "out %al, $0xA1\n"
            "mov $0x04, %al\n"
            "out %al, $0x21\n"
            "mov $0x02, %al\n"
            "out %al, $0xA1\n"
            "mov $0x01, %al\n"
            "out %al, $0x21\n"
            "out %al, $0xA1\n"
            "mov $0x0, %al\n"
            "out %al, $0x21\n"
            "out %al, $0xA1\n"
        );
        
        load_idt((uint32_t)&idt_ptr);
        enable();
        
        Console::write("🛡️ Interrupts: Full IDT and PIC initialization complete\n");
    }
    
    void register_handler(uint8_t interrupt, void (*handler)()) {
        interrupt_handlers[interrupt] = handler;
    }
    
    void enable() {
        asm volatile("sti");
    }
    
    void disable() {
        asm volatile("cli");
    }
}

// Реализации функций
extern "C" void default_handler() {
    asm volatile("iret");
}

extern "C" void interrupt_handler(uint32_t interrupt) {
    if (interrupt_handlers[interrupt]) {
        interrupt_handlers[interrupt]();
    }
    
    // Отправляем EOI в PIC
    if (interrupt >= 32 && interrupt < 40) {
        asm volatile("outb %0, $0x20" : : "a"((uint8_t)0x20));
    } else if (interrupt >= 40 && interrupt < 48) {
        asm volatile("outb %0, $0x20" : : "a"((uint8_t)0x20));
        asm volatile("outb %0, $0xA0" : : "a"((uint8_t)0x20));
    }
}

static void set_idt_entry(uint8_t num, uint32_t offset, uint16_t selector, uint8_t flags) {
    idt[num].offset_low = offset & 0xFFFF;
    idt[num].offset_high = (offset >> 16) & 0xFFFF;
    idt[num].selector = selector;
    idt[num].zero = 0;
    idt[num].type_attr = flags;
}

extern "C" void load_idt(uint32_t idt_ptr) {
    asm volatile("lidt (%0)" : : "r"(idt_ptr));
}
