// kernel/interrupts.h
#pragma once
#include <stdint.h>  // Добавляем для uint8_t, uint32_t

namespace Interrupts {
    void initialize();
    void register_handler(uint8_t interrupt, void (*handler)());
    void enable();
    void disable();
}
