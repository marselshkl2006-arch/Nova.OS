// kernel/kernel.cpp
#include <stdint.h>
#include "console.h"
#include "memory.h"
#include "process.h"
#include "interrupts.h"
#include "timer.h"
#include "keyboard.h"
#include "filesystem.h"
#include "syscalls.h"
#include "shell.h"
#include "paging.h"
#include "ata.h"
#include "fs_disk.h"
#include "microkernel.h"
#include "gui.h"
#include "gaming.h"
#include "compatibility.h"
#include "hal.h"

extern "C" void kernel_main() {
    // Инициализация основных систем NovaOS
    Console::initialize();
    MemoryManager::initialize();
    Paging::initialize();
    Interrupts::initialize();
    Timer::initialize(1000);
    Keyboard::initialize();
    
    // Файловые системы NovaOS
    FileSystem::initialize();
    ATA::initialize();
    FSDisk::initialize();
    
    // Гибридные компоненты NovaOS
    MicroKernel::initialize();
    GUI::initialize();
    Gaming::initialize();
    
    // Совместимость
    Compatibility::initialize();
    
    // Интерфейс NovaOS
    GUI::set_theme(GUI::Theme::NOVA_MODERN);
    
    Syscalls::initialize();
    ProcessScheduler::initialize();
    
    Console::write("🚀 NovaOS Hybrid v5.0 Booting...\n");
    Console::write("✨ Features: Universal Bootloader + NovaOS UI\n");
    
    // Включаем виртуальную память
    Paging::enable();
    
    // Тест универсальности
    HAL::initialize();
    Console::write("🌍 Architecture: ");
    Console::write(HAL::get_arch_name());
    Console::write("\n");
    
    // Запуск оболочки NovaOS
    Shell::initialize();
    
    Console::write("✅ NovaOS Ready! (Universal Boot: WORKING)\n");
    Console::write("   🎨 NovaOS Modern Interface\n");
    Console::write("   🔄 Universal Architecture Support\n"); 
    Console::write("   🎮 Gaming Optimization Ready\n");
    
    // Основной цикл NovaOS
    while(true) {
        asm volatile("hlt");
        ProcessScheduler::schedule();
        Shell::run();
    }
}
