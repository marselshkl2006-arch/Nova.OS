// kernel/keyboard.cpp
#include "keyboard.h"
#include "console.h"
#include <stdint.h>

static char key_buffer[256];
static int key_buffer_start = 0;
static int key_buffer_end = 0;

// Функция должна быть объявлена ДО использования
static char scancode_to_char(uint8_t scancode) {
    static const char* layout = "1234567890-=\b\tqwertyuiop[]\n asdfghjkl;'`\\ zxcvbnm,./ * ";
    
    if (scancode < 50) { // Простая проверка размера
        return layout[scancode];
    }
    return 0;
}

extern "C" void keyboard_handler() {
    uint8_t scancode;
    asm volatile("inb $0x60, %0" : "=a"(scancode));
    
    if (scancode < 0x80) { // Key press
        char c = scancode_to_char(scancode);
        if (c) {
            key_buffer[key_buffer_end] = c;
            key_buffer_end = (key_buffer_end + 1) % 256;
            Console::write_char(c);
        }
    }
}

namespace Keyboard {
    void initialize() {
        Console::write("⌨️ Keyboard initialized\n");
    }
    
    char get_char() {
        while (!has_key()) {
            asm volatile("hlt");
        }
        
        char c = key_buffer[key_buffer_start];
        key_buffer_start = (key_buffer_start + 1) % 256;
        return c;
    }
    
    bool has_key() {
        return key_buffer_start != key_buffer_end;
    }
}
