// kernel/keyboard.h
#pragma once
#include <stdint.h>

namespace Keyboard {
    void initialize();
    char get_char();
    bool has_key();
}
