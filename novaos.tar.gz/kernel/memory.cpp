// kernel/memory.cpp
#include "memory.h"

#define KERNEL_HEAP_SIZE (1024 * 1024 * 16) // 16MB
static uint8_t kernel_heap[KERNEL_HEAP_SIZE];
static MemoryManager::MemoryBlock* free_list = nullptr;
static size_t total_allocated = 0;

namespace MemoryManager {
    void initialize() {
        free_list = (MemoryBlock*)kernel_heap;
        free_list->size = KERNEL_HEAP_SIZE - sizeof(MemoryBlock);
        free_list->used = false;
        free_list->next = nullptr;
        total_allocated = 0;
    }
    
    void* malloc(size_t size) {
        // Выравнивание до 8 байт
        size = (size + 7) & ~7;
        
        MemoryBlock* current = free_list;
        MemoryBlock* best_fit = nullptr;
        
        // Best-fit алгоритм
        while (current) {
            if (!current->used && current->size >= size) {
                if (!best_fit || current->size < best_fit->size) {
                    best_fit = current;
                }
            }
            current = current->next;
        }
        
        if (!best_fit) return nullptr;
        
        // Разделяем блок если нужно
        if (best_fit->size > size + sizeof(MemoryBlock) + 8) {
            MemoryBlock* new_block = (MemoryBlock*)((uint8_t*)best_fit + sizeof(MemoryBlock) + size);
            new_block->size = best_fit->size - size - sizeof(MemoryBlock);
            new_block->used = false;
            new_block->next = best_fit->next;
            
            best_fit->size = size;
            best_fit->next = new_block;
        }
        
        best_fit->used = true;
        total_allocated += best_fit->size + sizeof(MemoryBlock);
        
        return (void*)((uint8_t*)best_fit + sizeof(MemoryBlock));
    }
    
    void free(void* ptr) {
        if (!ptr) return;
        
        MemoryBlock* block = (MemoryBlock*)((uint8_t*)ptr - sizeof(MemoryBlock));
        total_allocated -= block->size + sizeof(MemoryBlock);
        block->used = false;
        
        // Слияние с соседними свободными блоками
        MemoryBlock* current = free_list;
        while (current) {
            if (!current->used) {
                // Слияние с правым блоком
                if (current->next && !current->next->used) {
                    current->size += sizeof(MemoryBlock) + current->next->size;
                    current->next = current->next->next;
                }
            }
            current = current->next;
        }
    }
    
    size_t get_free_memory() {
        return KERNEL_HEAP_SIZE - total_allocated;
    }
    
    size_t get_total_memory() {
        return KERNEL_HEAP_SIZE;
    }
    
    size_t get_used_memory() {  // ДОБАВЛЯЕМ РЕАЛИЗАЦИЮ
        return total_allocated;
    }
}

extern "C" void* kmalloc(size_t size) {
    return MemoryManager::malloc(size);
}

extern "C" void kfree(void* ptr) {
    MemoryManager::free(ptr);
}