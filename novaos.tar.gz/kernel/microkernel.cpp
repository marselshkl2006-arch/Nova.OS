#include "microkernel.h"
#include "console.h"

namespace MicroKernel {
    void initialize() {
        Console::write("🔧 Microkernel IPC initialized\n");
    }
    
    bool send_message(const Message& msg) {
        Console::write("📨 IPC: Message sent from ");
        Console::write_number(msg.from_pid);
        Console::write(" to ");
        Console::write_number(msg.to_pid);
        Console::write("\n");
        return true;
    }
    
    bool receive_message(Message& msg) {
        // Заглушка - нет сообщений в очереди
        return false;
    }
    
    bool check_capability(uint32_t pid, void* resource, uint32_t permission) {
        Console::write("🔒 Capability check: PID ");
        Console::write_number(pid);
        Console::write("\n");
        return true;
    }
}
