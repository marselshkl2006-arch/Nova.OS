// kernel/novaui_theme.h
#pragma once
#include <stdint.h>

namespace NovaUI {
    void initialize();
    void set_dark_mode(bool enable);
    void apply_theme();
}