// kernel/paging.cpp
#include "paging.h"
#include "console.h"
#include "memory.h"

struct PageTableEntry {
    uint32_t present : 1;
    uint32_t writable : 1;
    uint32_t user : 1;
    uint32_t write_through : 1;
    uint32_t cache_disable : 1;
    uint32_t accessed : 1;
    uint32_t dirty : 1;
    uint32_t page_size : 1;
    uint32_t global : 1;
    uint32_t available : 3;
    uint32_t frame : 20;
} __attribute__((packed));

struct PageDirectoryEntry {
    uint32_t present : 1;
    uint32_t writable : 1;
    uint32_t user : 1;
    uint32_t write_through : 1;
    uint32_t cache_disable : 1;
    uint32_t accessed : 1;
    uint32_t reserved : 1;
    uint32_t page_size : 1;
    uint32_t global : 1;
    uint32_t available : 3;
    uint32_t table_address : 20;
} __attribute__((packed));

static PageDirectoryEntry* page_directory = nullptr;
static PageTableEntry* first_page_table = nullptr;

extern "C" void load_page_directory(uint32_t);
extern "C" void enable_paging();

namespace Paging {
    void initialize() {
        // Выделяем память для page directory
        page_directory = (PageDirectoryEntry*)MemoryManager::malloc(sizeof(PageDirectoryEntry) * 1024);
        first_page_table = (PageTableEntry*)MemoryManager::malloc(sizeof(PageTableEntry) * 1024);
        
        // Инициализируем page directory
        for (int i = 0; i < 1024; i++) {
            page_directory[i].present = 0;
            page_directory[i].writable = 1;
            page_directory[i].user = 0;
        }
        
        // Настраиваем первую page table для идентичного отображения первых 4MB
        for (int i = 0; i < 1024; i++) {
            first_page_table[i].present = 1;
            first_page_table[i].writable = 1;
            first_page_table[i].user = 0;
            first_page_table[i].frame = i;  // identity mapping
        }
        
        // Устанавливаем первую запись в page directory
        page_directory[0].present = 1;
        page_directory[0].writable = 1;
        page_directory[0].table_address = ((uint32_t)first_page_table) >> 12;
        
        Console::write("🗂️ Paging: Full initialization complete\n");
    }
    
    void map_page(uint32_t virtual_addr, uint32_t physical_addr, bool writable) {
        uint32_t page_dir_index = virtual_addr >> 22;
        uint32_t page_table_index = (virtual_addr >> 12) & 0x3FF;
        
        if (page_dir_index == 0) {
            first_page_table[page_table_index].present = 1;
            first_page_table[page_table_index].writable = writable;
            first_page_table[page_table_index].frame = physical_addr >> 12;
        }
    }
    
    void unmap_page(uint32_t virtual_addr) {
        uint32_t page_dir_index = virtual_addr >> 22;
        uint32_t page_table_index = (virtual_addr >> 12) & 0x3FF;
        
        if (page_dir_index == 0) {
            first_page_table[page_table_index].present = 0;
        }
    }
    
    void enable() {
        load_page_directory((uint32_t)page_directory);
        enable_paging();
        Console::write("🔒 Paging: Full paging enabled\n");
    }
    
    uint32_t get_physical_address(uint32_t virtual_addr) {
        uint32_t page_dir_index = virtual_addr >> 22;
        uint32_t page_table_index = (virtual_addr >> 12) & 0x3FF;
        
        if (page_dir_index == 0 && first_page_table[page_table_index].present) {
            return (first_page_table[page_table_index].frame << 12) | (virtual_addr & 0xFFF);
        }
        return virtual_addr; // Identity mapping fallback
    }
}

extern "C" void load_page_directory(uint32_t pd) {
    asm volatile("mov %0, %%cr3" : : "r"(pd));
}

extern "C" void enable_paging() {
    uint32_t cr0;
    asm volatile("mov %%cr0, %0" : "=r"(cr0));
    cr0 |= 0x80000000;
    asm volatile("mov %0, %%cr0" : : "r"(cr0));
}
