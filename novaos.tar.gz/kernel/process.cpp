// kernel/process.cpp
#include "process.h"
#include "memory.h"
#include "console.h"

static ProcessControlBlock* current_process = nullptr;
static ProcessControlBlock* process_list = nullptr;
static uint32_t next_pid = 1;
static ProcessControlBlock idle_process;

extern "C" void switch_context(uint32_t** old_sp, uint32_t* new_sp);

namespace ProcessScheduler {
    void initialize() {
        // Создаем idle процесс
        idle_process.pid = 0;
        idle_process.state = ProcessState::READY;
        idle_process.name = "idle";
        idle_process.priority = 0;
        idle_process.next = nullptr;
        
        current_process = &idle_process;
        process_list = &idle_process;
        
        Console::write("🔄 Process Scheduler: Full initialization\n");
    }
    
    void start() {
        create_process("init", nullptr);
        Console::write("🚀 Process Scheduler: Started with init process\n");
    }
    
    void schedule() {
        // Round-robin планировщик
        if (!process_list || !process_list->next) return;
        
        ProcessControlBlock* prev = nullptr;
        ProcessControlBlock* curr = process_list;
        
        // Ищем следующий готовый процесс
        while (curr) {
            if (curr->state == ProcessState::READY && curr != current_process) {
                if (prev) prev->next = curr->next;
                if (process_list == curr) process_list = curr->next;
                
                // Переключаем контекст
                ProcessControlBlock* old = current_process;
                current_process = curr;
                old->state = ProcessState::READY;
                curr->state = ProcessState::RUNNING;
                
                switch_context(&(old->stack_pointer), curr->stack_pointer);
                return;
            }
            prev = curr;
            curr = curr->next;
        }
    }
    
    void create_process(const char* name, void (*entry_point)()) {
        ProcessControlBlock* pcb = (ProcessControlBlock*)MemoryManager::malloc(sizeof(ProcessControlBlock));
        if (!pcb) return;
        
        pcb->pid = next_pid++;
        pcb->state = ProcessState::READY;
        pcb->name = name;
        pcb->priority = 1;
        pcb->stack_pointer = (uint32_t*)MemoryManager::malloc(4096); // 4KB стек
        pcb->next = process_list;
        process_list = pcb;
        
        // Инициализация контекста процесса
        if (entry_point && pcb->stack_pointer) {
            uint32_t* stack_top = (uint32_t*)((uint8_t*)pcb->stack_pointer + 4096); // Верх стека
            stack_top--; // Резервируем место
            *stack_top = 0x202; // EFLAGS
            stack_top--;
            *stack_top = 0x8;   // CS
            stack_top--;
            *stack_top = (uint32_t)entry_point; // EIP
            
            // Сохраняем указатель на стек
            pcb->stack_pointer = stack_top;
        }
        
        Console::write("📝 Process created: ");
        Console::write(name);
        Console::write(" (PID: ");
        Console::write_number(pcb->pid);
        Console::write(")\n");
    }
    
    ProcessControlBlock* get_current_process() {
        return current_process;
    }
    
    void set_priority(int priority) {
        if (current_process) {
            current_process->priority = priority;
        }
    }
}

// Полная реализация switch_context
__asm__(R"(
.global switch_context
switch_context:
    # Сохраняем контекст текущего процесса
    pushf
    pusha
    
    # Сохраняем ESP в old_sp
    mov 4(%esp), %eax
    mov %esp, (%eax)
    
    # Загружаем новый ESP из new_sp
    mov 8(%esp), %esp
    
    # Восстанавливаем контекст нового процесса
    popa
    popf
    
    ret
)");
