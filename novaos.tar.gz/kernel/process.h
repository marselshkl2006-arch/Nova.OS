// kernel/process.h
#pragma once
#include <stdint.h>

enum class ProcessState {
    CREATED, READY, RUNNING, BLOCKED, TERMINATED
};

struct ProcessControlBlock {
    uint32_t pid;
    ProcessState state;
    uint32_t* stack_pointer;
    uint32_t priority;
    const char* name;
    ProcessControlBlock* next;
};

namespace ProcessScheduler {
    void initialize();
    void start();
    void schedule();  // ДОБАВЛЯЕМ
    void create_process(const char* name, void (*entry_point)());
    ProcessControlBlock* get_current_process();
}