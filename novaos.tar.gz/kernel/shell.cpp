// kernel/shell.cpp
#include "shell.h"
#include "console.h"
#include "filesystem.h"
#include "keyboard.h"
#include "memory.h"
#include "string.h"
#include "fs_disk.h"
#include "gui.h"
#include "compatibility.h"
#include "gaming.h"
#include "hal.h"

static char input_buffer[256];
static int input_pos = 0;

namespace Shell {
    void initialize() {
        Console::write("🐚 NovaOS Universal Shell v1.0\n");
        Console::write("Type 'help' for cross-platform commands\n> ");
        
        FileSystem::write_text_to_file("readme.txt", "Welcome to NovaOS Universal!");
        FileSystem::write_text_to_file("system.cfg", "version=5.0-universal");
    }
    
    void run() {
        while (true) {
            if (Keyboard::has_key()) {
                char c = Keyboard::get_char();
                
                if (c == '\n') {
                    Console::write("\n");
                    input_buffer[input_pos] = '\0';
                    execute_command(input_buffer);
                    input_pos = 0;
                    Console::write("novaos> ");
                } else if (c == '\b') {
                    if (input_pos > 0) {
                        input_pos--;
                        Console::write_char('\b');
                    }
                } else if (input_pos < 255) {
                    input_buffer[input_pos++] = c;
                }
            }
        }
    }
    
    void execute_command(const char* command) {
        if (strcmp(command, "help") == 0) {
            Console::write("NovaOS Universal Commands:\n");
            Console::write("  help        - Show this help\n");
            Console::write("  clear       - Clear screen\n");
            Console::write("  ls          - List memory files\n");
            Console::write("  cat <file>  - Show file contents\n");
            Console::write("  mem         - Show memory info\n");
            Console::write("  ps          - Show processes\n");
            Console::write("  create <file> - Create new file\n");
            Console::write("  disk        - List disk files\n");
            Console::write("  dread <file> - Read file from disk\n");
            Console::write("  paging      - Show paging status\n");
            Console::write("  theme       - Change NovaOS theme\n");
            Console::write("  arch        - Show architecture info\n");
            Console::write("  compat <api> - Set compatibility layer\n");
            Console::write("  game mode   - Toggle gaming optimization\n");
            Console::write("  universal   - Test universal features\n");
        }
        else if (strcmp(command, "clear") == 0) {
            Console::clear();
        }
        else if (strcmp(command, "ls") == 0) {
            FileSystem::list_files();
        }
        else if (strcmp(command, "mem") == 0) {
            Console::write("NovaOS Memory: ");
            Console::write_number(MemoryManager::get_free_memory() / 1024);
            Console::write("KB free / ");
            Console::write_number(MemoryManager::get_total_memory() / 1024);
            Console::write("KB total\n");
        }
        else if (strcmp(command, "ps") == 0) {
            Console::write("NovaOS Processes: kernel, shell\n");
        }
        else if (strncmp(command, "cat ", 4) == 0) {
            const char* filename = command + 4;
            FileSystem::read_and_print_file(filename);
        }
        else if (strncmp(command, "create ", 7) == 0) {
            const char* filename = command + 7;
            FileSystem::create_file(filename);
        }
        else if (strcmp(command, "disk") == 0) {
            FSDisk::list_files();
        }
        else if (strncmp(command, "dread ", 6) == 0) {
            const char* filename = command + 6;
            char buffer[512];
            if (FSDisk::read_file(filename, buffer)) {
                Console::write("NovaOS Disk: ");
                Console::write(buffer);
                Console::write("\n");
            }
        }
        else if (strcmp(command, "paging") == 0) {
            Console::write("NovaOS Paging: ENABLED\n");
        }
        else if (strcmp(command, "theme") == 0) {
            GUI::set_theme(GUI::Theme::NOVA_DARK);
            Console::write("NovaOS Theme: Dark Mode Activated\n");
        }
        else if (strcmp(command, "arch") == 0) {
            Console::write("NovaOS Architecture: ");
            Console::write(HAL::get_arch_name());
            Console::write(" (");
            Console::write(HAL::get_device_name());
            Console::write(")\n");
        }
        else if (strncmp(command, "compat ", 7) == 0) {
            const char* api = command + 7;
            if (strcmp(api, "linux") == 0) {
                Compatibility::set_compatibility_layer(Compatibility::LINUX_API);
                Console::write("NovaOS Compatibility: Linux API enabled\n");
            }
            else if (strcmp(api, "windows") == 0) {
                Compatibility::set_compatibility_layer(Compatibility::WINDOWS_API);
                Console::write("NovaOS Compatibility: Windows API enabled\n");
            }
            else if (strcmp(api, "posix") == 0) {
                Compatibility::set_compatibility_layer(Compatibility::POSIX_API);
                Console::write("NovaOS Compatibility: POSIX API enabled\n");
            }
            else {
                Console::write("Unknown API. Use: linux, windows, posix\n");
            }
        }
        else if (strcmp(command, "game mode on") == 0) {
            Gaming::enable_game_mode();
            Console::write("NovaOS Gaming: Optimization enabled\n");
        }
        else if (strcmp(command, "game mode off") == 0) {
            Gaming::disable_game_mode();
            Console::write("NovaOS Gaming: Optimization disabled\n");
        }
        else if (strcmp(command, "universal") == 0) {
            Console::write("🧪 Testing NovaOS Universal Features:\n");
            Console::write("  ✅ Universal Bootloader\n");
            Console::write("  ✅ Cross-Architecture Support\n");
            Console::write("  ✅ Multi-Platform Compatibility\n");
            Console::write("  ✅ Adaptive UI System\n");
            Console::write("  ✅ Universal Binary Format\n");
        }
        else if (strcmp(command, "") == 0) {
            // Пустая команда
        }
        else {
            Console::write("Unknown NovaOS command: ");
            Console::write(command);
            Console::write("\nType 'help' for universal commands\n");
        }
    }
}
