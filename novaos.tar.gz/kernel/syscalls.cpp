// kernel/syscalls.cpp
#include "syscalls.h"
#include "console.h"
#include "filesystem.h"
#include "process.h"

namespace Syscalls {
    void initialize() {
        Console::write("📞 System calls initialized\n");
    }
    
    void handle_syscall(uint32_t syscall_num, uint32_t arg1, uint32_t arg2, uint32_t arg3) {
        switch (syscall_num) {
            case SYS_WRITE: {
                const char* str = (const char*)arg1;
                Console::write(str);
                break;
            }
            
            case SYS_OPEN: {
                const char* filename = (const char*)arg1;
                File* file = FileSystem::open(filename);
                // Возвращаем файловый дескриптор (пока просто указатель)
                asm volatile("mov %0, %%eax" : : "r"((uint32_t)file));
                break;
            }
            
            case SYS_READ: {
                File* file = (File*)arg1;
                void* buffer = (void*)arg2;
                size_t size = (size_t)arg3;
                size_t bytes_read = FileSystem::read(file, buffer, size);
                asm volatile("mov %0, %%eax" : : "r"(bytes_read));
                break;
            }
            
            case SYS_EXIT: {
                ProcessControlBlock* pcb = ProcessScheduler::get_current_process();
                if (pcb && pcb->pid != 0) {
                    pcb->state = ProcessState::TERMINATED;
                }
                break;
            }
            
            default:
                Console::write("❌ Unknown syscall: ");
                Console::write_number(syscall_num);
                Console::write("\n");
                break;
        }
    }
}

// Обработчик прерывания системного вызова
extern "C" void syscall_handler() {
    uint32_t syscall_num, arg1, arg2, arg3;
    
    asm volatile(
        "mov %%eax, %0\n"
        "mov %%ebx, %1\n"
        "mov %%ecx, %2\n"
        "mov %%edx, %3\n"
        : "=r"(syscall_num), "=r"(arg1), "=r"(arg2), "=r"(arg3)
    );
    
    Syscalls::handle_syscall(syscall_num, arg1, arg2, arg3);
}