// kernel/syscalls.h
#pragma once
#include <stdint.h>

namespace Syscalls {
    void initialize();
    
    // Номера системных вызовов
    enum {
        SYS_WRITE = 1,
        SYS_READ = 2,
        SYS_OPEN = 3,
        SYS_CLOSE = 4,
        SYS_EXIT = 5,
        SYS_FORK = 6,
        SYS_EXEC = 7
    };
    
    void handle_syscall(uint32_t syscall_num, uint32_t arg1, uint32_t arg2, uint32_t arg3);
}