// kernel/timer.cpp
#include "timer.h"
#include "interrupts.h"
#include "console.h"
#include <stdint.h>

static uint64_t timer_ticks = 0;

extern "C" void timer_handler() {
    timer_ticks++;
}

namespace Timer {
    void initialize(uint32_t frequency) {
        // Программируем PIT (Programmable Interval Timer)
        uint32_t divisor = 1193180 / frequency;
        
        asm volatile("cli");
        // Отправляем команду
        asm volatile("outb %0, %1" : : "a"((uint8_t)0x36), "Nd"((uint16_t)0x43));
        // Отправляем делитель
        asm volatile("outb %0, %1" : : "a"((uint8_t)(divisor & 0xFF)), "Nd"((uint16_t)0x40));
        asm volatile("outb %0, %1" : : "a"((uint8_t)((divisor >> 8) & 0xFF)), "Nd"((uint16_t)0x40));
        asm volatile("sti");
        
        // Регистрируем обработчик прерывания
        Interrupts::register_handler(32, timer_handler);
        Console::write("⏰ Timer: Full PIT initialization at ");
        Console::write_number(frequency);
        Console::write(" Hz\n");
    }
    
    uint64_t get_ticks() {
        return timer_ticks;
    }
    
    void sleep(uint32_t ms) {
        uint64_t target = timer_ticks + ms;
        while (timer_ticks < target) {
            asm volatile("hlt");
        }
    }
}
