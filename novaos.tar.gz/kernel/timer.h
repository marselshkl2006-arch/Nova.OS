// kernel/timer.h
#pragma once
#include <stdint.h>

namespace Timer {
    void initialize(uint32_t frequency);
    uint64_t get_ticks();
    void sleep(uint32_t ms);
}
