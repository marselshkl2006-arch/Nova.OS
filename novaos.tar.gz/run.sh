#!/bin/bash
qemu-system-i386 -kernel novaos.bin -serial stdio -display none
